import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tasabeeh/state.dart';
import 'package:tasabeeh/theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('كل السمات والألوان المخصصة تبني ثيمًا صالحًا', () {
    for (var i = 0; i < palettes.length; i++) {
      for (final b in Brightness.values) {
        final t = buildTheme(b, i, null);
        expect(t.colorScheme.brightness, b);
        expect(t.colorScheme.primary == t.scaffoldBackgroundColor, isFalse, reason: palettes[i].name);
        final t2 = buildTheme(b, i, accentPresets.first);
        expect(t2.colorScheme.onPrimary == t2.colorScheme.primary, isFalse);
      }
    }
  });

  test('حفظ المظهر واسترجاعه', () async {
    SharedPreferences.setMockInitialValues({});
    final s = AppState();
    await s.load();
    s.setTheme(mode: 'light', pal: 2);
    s.setTheme(acc: 0xFF4A90E2);
    final s2 = AppState();
    await s2.load();
    expect(s2.themeMode, 'light');
    expect(s2.palette, 2);
    expect(s2.accent, 0xFF4A90E2);
    s2.setTheme(pal: 1);
    expect(s2.accent, isNull);
  });
}
