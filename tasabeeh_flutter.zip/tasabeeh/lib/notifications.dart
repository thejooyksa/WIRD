import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

class Notifier {
  static final _plugin = FlutterLocalNotificationsPlugin();

  /// يحمل حمولة الإشعار الذي ضغط عليه المستخدم (azkar_m أو azkar_e)
  static final payload = ValueNotifier<String?>(null);

  /// يُضبط من main: ينفّذ زر «+١» و«تراجع» عندما يكون التطبيق في الواجهة
  static void Function(NotificationResponse)? actionHandler;

  static bool _isCounterAction(NotificationResponse r) => r.actionId == 'count_plus' || r.actionId == 'count_undo';

  /// تهيئة مختصرة تُستعمل داخل معالج الخلفية (بدون المنطقة الزمنية)
  static Future<void> initBasic() async {
    try {
      await _plugin.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
    } catch (_) {}
  }

  static Future<void> init({DidReceiveBackgroundNotificationResponseCallback? onBackground}) async {
    try {
      tzdata.initializeTimeZones();
      tz.setLocalLocation(tz.getLocation(await FlutterTimezone.getLocalTimezone()));
      await _plugin.initialize(
        const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
        onDidReceiveNotificationResponse: (r) {
          if (_isCounterAction(r)) {
            actionHandler?.call(r);
          } else {
            payload.value = r.payload;
          }
        },
        onDidReceiveBackgroundNotificationResponse: onBackground,
      );
      final d = await _plugin.getNotificationAppLaunchDetails();
      if (d?.didNotificationLaunchApp ?? false) {
        payload.value = d!.notificationResponse?.payload;
      }
    } catch (_) {}
  }

  static Future<void> _daily(int id, int hour, int minute, String title, String body,
      String channel, String channelName, String? pl) async {
    try {
      await _plugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
      final now = tz.TZDateTime.now(tz.local);
      var when = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
      if (when.isBefore(now)) when = when.add(const Duration(days: 1));
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        when,
        NotificationDetails(
          android: AndroidNotificationDetails(channel, channelName,
              importance: Importance.high, priority: Priority.high),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
        payload: pl,
      );
    } catch (_) {}
  }

  static Future<void> schedule(int h, int m) => _daily(1, h, m, 'وقت الذكر',
      'سبّح الله واذكره… دقائق قليلة تكفي', 'tasabeeh_daily', 'التذكير اليومي', null);

  static Future<void> scheduleAzkar(bool morning, int h, int m) => _daily(
      morning ? 2 : 3,
      h,
      m,
      morning ? 'أذكار الصباح' : 'أذكار المساء',
      morning ? 'حان وقت أذكار الصباح، اضغط للبدء' : 'حان وقت أذكار المساء، اضغط للبدء',
      'tasabeeh_azkar',
      'تذكير الأذكار',
      morning ? 'azkar_m' : 'azkar_e');

  /// إشعار دائم للعدّ السريع من الشاشة المقفلة
  static Future<void> showCounter({required String title, required String body}) async {
    try {
      await _plugin.show(
        4,
        title,
        body,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'tasabeeh_counter',
            'العدّ السريع',
            channelDescription: 'إشعار دائم فيه زر +١ للعدّ من الشاشة المقفلة',
            importance: Importance.low,
            priority: Priority.low,
            ongoing: true,
            autoCancel: false,
            onlyAlertOnce: true,
            showWhen: false,
            playSound: false,
            enableVibration: false,
            visibility: NotificationVisibility.public,
            actions: <AndroidNotificationAction>[
              AndroidNotificationAction('count_plus', '+١', showsUserInterface: false, cancelNotification: false),
              AndroidNotificationAction('count_undo', 'تراجع', showsUserInterface: false, cancelNotification: false),
            ],
          ),
        ),
      );
    } catch (_) {}
  }

  static Future<void> cancelCounter() => _cancel(4);

  /// إشعار لمرة واحدة في وقت محدد (قبل الصلاة، الإقامة، ...)
  static Future<void> oneShot(int id, tz.TZDateTime when, String title, String body,
      {String channel = 'tasabeeh_prayer', String channelName = 'أوقات الصلاة'}) async {
    try {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        when,
        NotificationDetails(
          android: AndroidNotificationDetails(channel, channelName, importance: Importance.high, priority: Priority.high),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      );
    } catch (_) {}
  }

  /// تذكير يومي متكرر بورد الذكر
  static Future<void> scheduleWird(int id, int h, int m, String body) =>
      _daily(id, h, m, 'ورد الذكر', body, 'tasabeeh_wird', 'ورد الذكر', 'wird');

  static Future<void> cancelWird(int id) => _cancel(id);

  static Future<void> scheduleKhatma(int h, int m) => _daily(
      5, h, m, 'ورد القرآن', 'حان وقت وردك اليوم من القرآن', 'tasabeeh_khatma', 'ورد القرآن', 'khatma');

  static Future<void> cancelKhatma() => _cancel(5);

  static Future<void> occasionAt(int id, tz.TZDateTime when, String name) async {
    try {
      await _plugin.zonedSchedule(
        id,
        'مناسبة قادمة',
        'غدًا: $name',
        when,
        const NotificationDetails(
          android: AndroidNotificationDetails('tasabeeh_occasions', 'المناسبات الهجرية',
              importance: Importance.defaultImportance, priority: Priority.defaultPriority),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: 'occasion',
      );
    } catch (_) {}
  }

  static Future<void> requestPermission() async {
    try {
      await _plugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
    } catch (_) {}
  }

  static Future<void> prayerAt(int id, tz.TZDateTime when, String name, {bool adhan = false}) async {
    try {
      await _plugin.zonedSchedule(
        id,
        'حان وقت صلاة $name',
        'حان الآن موعد صلاة $name',
        when,
        NotificationDetails(
          android: AndroidNotificationDetails(
            adhan ? 'tasabeeh_prayer_adhan' : 'tasabeeh_prayer',
            adhan ? 'أذان' : 'أوقات الصلاة',
            importance: Importance.high,
            priority: Priority.high,
            playSound: true,
            // يتطلب ملف android/app/src/main/res/raw/adhan.mp3 (ضع تسجيلًا مرخّصًا)
            sound: adhan ? const RawResourceAndroidNotificationSound('adhan') : null,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        payload: 'prayer',
      );
    } catch (_) {}
  }

  static Future<void> cancelRange(int from, int to) async {
    for (var i = from; i < to; i++) {
      await _cancel(i);
    }
  }

  static Future<void> _cancel(int id) async {
    try {
      await _plugin.cancel(id);
    } catch (_) {}
  }

  static Future<void> cancel() => _cancel(1);
  static Future<void> cancelAzkar(bool morning) => _cancel(morning ? 2 : 3);
}
