import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:timezone/timezone.dart' as tz;
import 'notifications.dart';
import 'occasions.dart';
import 'prayer.dart';

class Dhikr {
  final String id, text;
  final int target;
  final bool custom;
  const Dhikr(this.id, this.text, this.target, {this.custom = false});
  Map<String, dynamic> toJson() => {'id': id, 'text': text, 'target': target};
}

const defaultAzkar = [
  Dhikr('subhan', 'سبحان الله', 33),
  Dhikr('hamd', 'الحمد لله', 33),
  Dhikr('akbar', 'الله أكبر', 34),
  Dhikr('tahleel', 'لا إله إلا الله', 100),
  Dhikr('istighfar', 'أستغفر الله', 100),
  Dhikr('subhan_bihamdih', 'سبحان الله وبحمده', 100),
  Dhikr('hawqala', 'لا حول ولا قوة إلا بالله', 100),
  Dhikr('salat', 'اللهم صلِّ وسلم على نبينا محمد', 100),
];

String dayKey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

/// يضبطه الإعداد «الأرقام» (عربية أو إنجليزية)
bool useArabicDigits = true;

/// خط القرآن والأذكار الحالي (يضبطه الإعداد «الخط»)
String quranFont = 'Amiri';

String ar(num n) {
  if (!useArabicDigits) return n.toString();
  const d = '٠١٢٣٤٥٦٧٨٩';
  return n.toString().split('').map((c) {
    final i = int.tryParse(c);
    return i == null ? c : d[i];
  }).join();
}

typedef Achievement = ({String title, String desc, bool ok});

class AppState extends ChangeNotifier {
  late SharedPreferences _p;
  List<Dhikr> customAzkar = [];
  String currentId = 'subhan';
  Map<String, int> session = {}; // العدّ الحالي لكل ذكر
  Map<String, int> history = {}; // مجموع كل يوم
  Map<String, int> lifetime = {}; // المجموع الكلي لكل ذكر
  Map<String, int> targets = {}; // أهداف معدّلة
  Map<String, int> az = {}; // تقدّم أذكار اليوم: التاريخ|الفئة|الذكر
  Map<String, Map<String, int>> hd = {}; // سجل التسبيح: اليوم ← الذكر ← العدد
  List<Map<String, dynamic>> uz = []; // قائمة أذكاري: id, m (النص), n (العدد)
  String digits = 'ar';
  bool onboarded = false;
  bool azAuto = true;
  int hAdj = 0; // تعديل التاريخ الهجري بالأيام (−٢ إلى +٢)
  bool amoled = false; // أسود كامل في الوضع الداكن
  String quranFontId = 'Amiri'; // خط القرآن والأذكار
  String uiFontId = ''; // خط الواجهة ('' = خط النظام)
  bool quickNotif = false; // إشعار العدّ السريع
  // متابعة الصلوات: اليوم ← قناع بتات (٥ صلوات)
  Map<String, int> pr = {};
  // ختمة القرآن
  bool khOn = false, khRem = false, occNotify = false;
  int khDays = 30, khCount = 0, khRemH = 21, khRemM = 0;
  String? khStart;
  List<int> khDone = [];
  String quranTab = 's';
  List<Occasion>? _occList;
  String _occDay = '';
  int dailyGoal = 100;
  bool haptics = true, sound = false, dark = true, reminder = false, seq = false;
  bool azMorning = DateTime.now().hour < 12, azMOn = false, azEOn = false;
  String azCat = DateTime.now().hour < 12 ? 'm' : 'e';
  int azMH = 6, azMM = 0, azEH = 17, azEM = 30;
  // المظهر: themeMode = auto | light | dark ، palette فهرس السمة، accent لون تمييز مخصص (ARGB)
  String themeMode = 'dark';
  int palette = 0;
  int? accent;
  // أوقات الصلاة
  int pCity = 0, pMethod = 0, pAsr = 1;
  double pLat = 21.4225, pLng = 39.8262;
  String pTz = 'Asia/Riyadh', pName = 'مكة المكرمة';
  List<int> pAdj = [0, 0, 0, 0, 0, 0];
  bool p24 = false, pNotify = false, pRam = true, pAdhan = false;
  int pPre = 0; // تذكير قبل دخول الوقت بالدقائق (٠ = إيقاف)
  bool pIqama = false; // إظهار الإقامة والتذكير بها
  List<int> pIq = [25, 15, 15, 10, 15]; // دقائق الإقامة بعد الأذان: فجر، ظهر، عصر، مغرب، عشاء
  bool wRem = false; // تذكير ورد الذكر اليومي
  List<int> wTimes = [600, 900]; // أوقات التذكير بالدقائق من منتصف الليل
  List<List<int>> marks = []; // علامات القراءة: [سورة، آية]

  tz.Location get pLoc {
    try {
      return pTz == 'local' ? tz.local : tz.getLocation(pTz);
    } catch (_) {
      return tz.local;
    }
  }

  List<double> prayerFor(int y, int m, int d) => PrayerCalc.times(
        y: y,
        m: m,
        d: d,
        lat: pLat,
        lng: pLng,
        tzh: tz.TZDateTime(pLoc, y, m, d, 12).timeZoneOffset.inMinutes / 60,
        method: prayerMethods[pMethod],
        asr: pAsr,
        adj: pAdj,
        ishaExtra: (pRam && pMethod == 0 && HijriCalendar.fromDate(DateTime(y, m, d).add(Duration(days: hAdj))).hMonth == 9) ? 30 : 0,
      );

  ({int i, Duration left, List<double> t}) nextPrayer() {
    final n = tz.TZDateTime.now(pLoc);
    final h = n.hour + n.minute / 60 + n.second / 3600;
    final t = prayerFor(n.year, n.month, n.day);
    for (final i in [0, 2, 3, 4, 5]) {
      if (t[i] > h) return (i: i, left: Duration(seconds: ((t[i] - h) * 3600).round()), t: t);
    }
    final u = tz.TZDateTime(pLoc, n.year, n.month, n.day + 1);
    final t2 = prayerFor(u.year, u.month, u.day);
    return (i: 0, left: Duration(seconds: ((t2[0] + 24 - h) * 3600).round()), t: t);
  }

  void updatePrayer(void Function() change) {
    change();
    _save();
    _applyPrayer();
    notifyListeners();
  }

  /// يجدول إشعارات الصلاة للأيام السبعة القادمة (وتتجدد كلما فُتح التطبيق)
  /// يجدول للأيام السبعة القادمة: الأذان، والتذكير قبله، والإقامة (وتتجدد كلما فُتح التطبيق)
  Future<void> _applyPrayer() async {
    await Notifier.cancelRange(100, 150);
    await Notifier.cancelRange(300, 350);
    await Notifier.cancelRange(400, 450);
    if (!pNotify && pPre == 0 && !pIqama) return;
    final now = tz.TZDateTime.now(pLoc);
    for (var day = 0; day < 7; day++) {
      final dt = tz.TZDateTime(pLoc, now.year, now.month, now.day + day);
      final t = prayerFor(dt.year, dt.month, dt.day);
      for (final i in [0, 2, 3, 4, 5]) {
        if (t[i].isNaN) continue;
        final when = tz.TZDateTime(pLoc, dt.year, dt.month, dt.day, 0, (t[i] * 60).round());
        final base = day * 6 + i;
        if (pNotify && when.isAfter(now)) await Notifier.prayerAt(100 + base, when, prayerNames[i], adhan: pAdhan);
        if (pPre > 0) {
          final w = when.subtract(Duration(minutes: pPre));
          if (w.isAfter(now)) {
            await Notifier.oneShot(300 + base, w, 'اقترب وقت صلاة ${prayerNames[i]}', 'بعد ${ar(pPre)} دقيقة يحين وقت صلاة ${prayerNames[i]}');
          }
        }
        final iq = pIq[iqamaIndex(i)];
        if (pIqama && iq > 0) {
          final w = when.add(Duration(minutes: iq));
          if (w.isAfter(now)) await Notifier.oneShot(400 + base, w, 'إقامة صلاة ${prayerNames[i]}', 'حان موعد إقامة صلاة ${prayerNames[i]}');
        }
      }
    }
  }

  // ───── تذكير ورد الذكر ─────
  Future<void> _applyWird() async {
    for (var i = 0; i < 4; i++) {
      await Notifier.cancelWird(6 + i);
    }
    if (!wRem) return;
    final body = 'سبّح الله واذكره. هدفك اليوم ${ar(dailyGoal)} تسبيحة';
    for (var i = 0; i < wTimes.length && i < 4; i++) {
      await Notifier.scheduleWird(6 + i, wTimes[i] ~/ 60, wTimes[i] % 60, body);
    }
  }

  void setWRem(bool on) {
    wRem = on;
    _save();
    notifyListeners();
    _applyWird();
  }

  void addWTime(int minutes) {
    if (wTimes.length >= 4 || wTimes.contains(minutes)) return;
    wTimes = [...wTimes, minutes]..sort();
    _save();
    notifyListeners();
    _applyWird();
  }

  void removeWTime(int index) {
    wTimes = [...wTimes]..removeAt(index);
    _save();
    notifyListeners();
    _applyWird();
  }
  double speed = 3, fs = 30;
  int bmSurah = 0;
  double bmY = 0;
  int remHour = 8, remMin = 0;

  List<Dhikr> get all => [...defaultAzkar, ...customAzkar];
  Dhikr get current =>
      all.firstWhere((d) => d.id == currentId, orElse: () => defaultAzkar.first);
  int get target => targets[currentId] ?? current.target;
  int get sessionCount => session[currentId] ?? 0;
  int get today => history[dayKey(DateTime.now())] ?? 0;
  int get total => lifetime.values.fold(0, (a, b) => a + b);

  int get streak {
    var day = DateTime.now();
    if ((history[dayKey(day)] ?? 0) == 0) {
      day = day.subtract(const Duration(days: 1));
    }
    var n = 0;
    while ((history[dayKey(day)] ?? 0) > 0) {
      n++;
      day = day.subtract(const Duration(days: 1));
    }
    return n;
  }

  int get bestStreak {
    final keys = history.entries.where((e) => e.value > 0).map((e) => e.key).toList()..sort();
    var best = 0, run = 0;
    DateTime? prev;
    for (final k in keys) {
      final p = k.split('-').map(int.parse).toList();
      final d = DateTime(p[0], p[1], p[2]);
      run = (prev != null && d.difference(prev).inDays == 1) ? run + 1 : 1;
      if (run > best) best = run;
      prev = d;
    }
    return best;
  }

  /// آخر 7 أيام (الأقدم أولًا)
  List<(DateTime, int)> get last7 {
    final now = DateTime.now();
    return List.generate(7, (i) {
      final d = now.subtract(Duration(days: 6 - i));
      return (d, history[dayKey(d)] ?? 0);
    });
  }

  List<Achievement> get achievements => [
        (title: 'البداية', desc: 'أول ١٠٠ تسبيحة', ok: total >= 100),
        (title: 'ألف تسبيحة', desc: 'مجموع ١٬٠٠٠', ok: total >= 1000),
        (title: 'عشرة آلاف', desc: 'مجموع ١٠٬٠٠٠', ok: total >= 10000),
        (title: 'مئة ألف', desc: 'مجموع ١٠٠٬٠٠٠', ok: total >= 100000),
        (title: 'ثلاثة أيام', desc: 'سلسلة ٣ أيام', ok: bestStreak >= 3),
        (title: 'أسبوع كامل', desc: 'سلسلة ٧ أيام', ok: bestStreak >= 7),
        (title: 'شهر من الذكر', desc: 'سلسلة ٣٠ يومًا', ok: bestStreak >= 30),
        (title: 'هدف اليوم', desc: 'أكملت هدفك اليومي', ok: today >= dailyGoal),
      ];

  // ───── العمليات ─────
  void tap({bool feedback = true}) {
    final id = currentId, t = target;
    final c = (session[id] ?? 0) + 1;
    session[id] = c;
    final k = dayKey(DateTime.now());
    history[k] = (history[k] ?? 0) + 1;
    lifetime[id] = (lifetime[id] ?? 0) + 1;
    final day = hd.putIfAbsent(k, () => {});
    day[id] = (day[id] ?? 0) + 1;
    if (hd.length > 40) {
      final ks = hd.keys.toList()..sort();
      while (ks.length > 40) {
        hd.remove(ks.removeAt(0));
      }
    }
    if (feedback && haptics) {
      c % t == 0 ? HapticFeedback.heavyImpact() : HapticFeedback.selectionClick();
    }
    if (feedback && sound) SystemSound.play(SystemSoundType.click);
    if (c % t == 0 && seq) {
      const o = ['subhan', 'hamd', 'akbar'];
      final i = o.indexOf(id);
      if (i > -1 && i < 2) {
        currentId = o[i + 1];
        session[currentId] = 0;
      } else {
        seq = false;
      }
    }
    _save();
    notifyListeners();
  }

  void undo() {
    final id = currentId;
    if ((session[id] ?? 0) <= 0) return;
    session[id] = session[id]! - 1;
    final k = dayKey(DateTime.now());
    if ((history[k] ?? 0) > 0) history[k] = history[k]! - 1;
    if ((lifetime[id] ?? 0) > 0) lifetime[id] = lifetime[id]! - 1;
    final dl = hd[k];
    if (dl != null && (dl[id] ?? 0) > 0) dl[id] = dl[id]! - 1;
    _save();
    notifyListeners();
  }

  void resetCurrent() {
    session[currentId] = 0;
    _save();
    notifyListeners();
  }

  void select(String id) {
    currentId = id;
    _save();
    notifyListeners();
  }

  void setTarget(int t) {
    if (t < 1) return;
    targets[currentId] = t;
    _save();
    notifyListeners();
  }

  void addCustom(String text, int target) {
    final d = Dhikr('c${DateTime.now().millisecondsSinceEpoch}', text, target, custom: true);
    customAzkar.add(d);
    currentId = d.id;
    _save();
    notifyListeners();
  }

  void removeCustom(String id) {
    customAzkar.removeWhere((d) => d.id == id);
    if (currentId == id) currentId = defaultAzkar.first.id;
    _save();
    notifyListeners();
  }

  void set({bool? haptics, bool? sound, bool? dark, int? goal}) {
    this.haptics = haptics ?? this.haptics;
    this.sound = sound ?? this.sound;
    this.dark = dark ?? this.dark;
    dailyGoal = goal ?? dailyGoal;
    if (goal != null) _applyWird();
    _save();
    notifyListeners();
  }

  Future<void> setReminder(bool on, {int? h, int? m}) async {
    reminder = on;
    remHour = h ?? remHour;
    remMin = m ?? remMin;
    on ? await Notifier.schedule(remHour, remMin) : await Notifier.cancel();
    _save();
    notifyListeners();
  }

  void azTap(String key, int n) {
    final today = dayKey(DateTime.now());
    az.removeWhere((k, _) => !k.startsWith('$today|'));
    final c = az[key] ?? 0;
    if (c >= n) return;
    az[key] = c + 1;
    if (haptics) HapticFeedback.selectionClick();
    _save();
    notifyListeners();
  }

  void azReset(String prefix) {
    az.removeWhere((k, _) => k.startsWith(prefix));
    _save();
    notifyListeners();
  }

  void setAzMorning(bool m) {
    azMorning = m;
    azCat = m ? 'm' : 'e';
    notifyListeners();
  }

  void setAzCat(String c) {
    azCat = c;
    notifyListeners();
  }

  void openAzkar(bool morning) => setAzMorning(morning);

  Future<void> _applyAz(bool morning) async {
    final on = morning ? azMOn : azEOn;
    final h = morning ? azMH : azEH, m = morning ? azMM : azEM;
    on ? await Notifier.scheduleAzkar(morning, h, m) : await Notifier.cancelAzkar(morning);
  }

  Future<void> setAzReminder(bool morning, bool on, {int? h, int? m}) async {
    if (morning) {
      azMOn = on;
      azMH = h ?? azMH;
      azMM = m ?? azMM;
    } else {
      azEOn = on;
      azEH = h ?? azEH;
      azEM = m ?? azEM;
    }
    await _applyAz(morning);
    _save();
    notifyListeners();
  }

  /// يعيد جدولة كل التذكيرات عند فتح التطبيق (بعد تغيير المنطقة الزمنية مثلًا)
  Future<void> rescheduleAll() async {
    if (reminder) await Notifier.schedule(remHour, remMin);
    await _applyAz(true);
    await _applyAz(false);
    await _applyPrayer();
    await _applyKh();
    await _applyOcc();
    await _applyWird();
  }

  void setTheme({String? mode, int? pal, int? acc, bool clearAccent = false}) {
    themeMode = mode ?? themeMode;
    if (pal != null) {
      palette = pal;
      accent = null;
    }
    if (acc != null) accent = acc;
    if (clearAccent) accent = null;
    _save();
    notifyListeners();
  }

  bool hasMark(int s, int a) => marks.any((m) => m[0] == s && m[1] == a);

  void toggleMark(int s, int a) {
    final i = marks.indexWhere((m) => m[0] == s && m[1] == a);
    i >= 0 ? marks.removeAt(i) : marks.add([s, a]);
    _save();
    notifyListeners();
  }

  void removeMarkAt(int i) {
    marks.removeAt(i);
    _save();
    notifyListeners();
  }

  /// نسخة احتياطية نصية (JSON) تُنسخ إلى الحافظة
  String exportJson() => jsonEncode({'app': 'tasabeeh', 'v': 1, ..._toMap()});

  Future<bool> importJson(String text) async {
    try {
      final m = jsonDecode(text.trim());
      if (m is! Map || m['app'] != 'tasabeeh') return false;
      m.remove('app');
      m.remove('v');
      await _p.setString('data', jsonEncode(m));
      await load();
      notifyListeners();
      await rescheduleAll();
      return true;
    } catch (_) {
      return false;
    }
  }

  List<MapEntry<String, int>> todayLog() =>
      ((hd[dayKey(DateTime.now())] ?? <String, int>{}).entries.where((e) => e.value > 0).toList())
        ..sort((a, b) => b.value.compareTo(a.value));

  String shareText() =>
      'سبّحتُ ${ar(today)} تسبيحة اليوم، وسلسلتي ${ar(streak)} يومًا، ومجموعي ${ar(total)}. تطبيق تسابيح';

  void setDigits(String d) {
    digits = d;
    useArabicDigits = d == 'ar';
    _save();
    notifyListeners();
  }

  // ───── متابعة الصلوات ─────
  String _dk(int off) => dayKey(DateTime.now().subtract(Duration(days: off)));
  int prMask(int off) => pr[_dk(off)] ?? 0;
  int prCount(int mask) {
    var c = 0;
    for (var i = 0; i < 5; i++) {
      if (((mask >> i) & 1) == 1) c++;
    }
    return c;
  }

  int get prStreak {
    var o = prMask(0) == 31 ? 0 : 1, n = 0;
    while (prMask(o) == 31) {
      n++;
      o++;
    }
    return n;
  }

  void togglePrayer(int off, int i) {
    final k = _dk(off);
    pr[k] = (pr[k] ?? 0) ^ (1 << i);
    _save();
    notifyListeners();
  }

  // ───── المناسبات الهجرية ─────
  List<Occasion> get occasions {
    final d = '${dayKey(DateTime.now())}|$hAdj';
    if (_occList == null || _occDay != d) {
      _occList = upcomingOccasions(DateTime.now(), adj: hAdj);
      _occDay = d;
    }
    return _occList!;
  }

  void setOccNotify(bool v) {
    occNotify = v;
    _save();
    notifyListeners();
    _applyOcc();
  }

  /// تذكير قبل المناسبة بيوم الساعة ٨ مساءً (للمناسبات خلال ٩٠ يومًا)
  Future<void> _applyOcc() async {
    await Notifier.cancelRange(200, 240);
    if (!occNotify) return;
    final list = upcomingOccasions(DateTime.now(), days: 90, max: 30, adj: hAdj);
    final now = tz.TZDateTime.now(tz.local);
    var id = 200;
    for (final o in list) {
      if (id >= 240) break;
      final when = tz.TZDateTime(tz.local, o.date.year, o.date.month, o.date.day - 1, 20);
      if (when.isAfter(now)) await Notifier.occasionAt(id++, when, o.name);
    }
  }

  // ───── ختمة القرآن ─────
  int khDaysSince() {
    if (khStart == null) return 0;
    final p = khStart!.split('-').map(int.parse).toList();
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day).difference(DateTime(p[0], p[1], p[2])).inDays;
  }

  int get khNext {
    for (var d = 1; d <= khDays; d++) {
      if (!khDone.contains(d)) return d;
    }
    return 0;
  }

  void setQuranTab(String t) {
    quranTab = t;
    notifyListeners();
  }

  void khSetDays(int d) {
    khDays = d;
    _save();
    notifyListeners();
  }

  void khStartPlan() {
    khOn = true;
    khStart = dayKey(DateTime.now());
    khDone = [];
    _save();
    notifyListeners();
    _applyKh();
  }

  void khMarkDone(int d) {
    if (!khDone.contains(d)) khDone.add(d);
    _save();
    notifyListeners();
  }

  void khFinish() {
    khCount++;
    khCancel();
  }

  void khCancel() {
    khOn = false;
    khDone = [];
    khStart = null;
    _save();
    notifyListeners();
    _applyKh();
  }

  void setKhRem(bool on, {int? h, int? m}) {
    khRem = on;
    khRemH = h ?? khRemH;
    khRemM = m ?? khRemM;
    _save();
    notifyListeners();
    _applyKh();
  }

  Future<void> _applyKh() async {
    if (khRem && khOn) {
      await Notifier.scheduleKhatma(khRemH, khRemM);
    } else {
      await Notifier.cancelKhatma();
    }
  }

  void setQuickNotif(bool v) {
    quickNotif = v;
    _save();
    if (!v) Notifier.cancelCounter();
    notifyListeners();
  }

  void refreshQuick() {
    if (quickNotif) _showQuick();
  }

  void _showQuick() {
    final t = target, c = sessionCount;
    final shown = (c > 0 && c % t == 0) ? t : c % t;
    Notifier.showCounter(title: current.text, body: 'العدد ${ar(shown)} من ${ar(t)}   |   اليوم ${ar(today)}');
  }

  /// يعيد قراءة البيانات (بعد أن عدّل معالج الخلفية العدّاد من الإشعار)
  Future<void> reload() async {
    await _p.reload();
    await load();
    notifyListeners();
  }

  Future<void> saveNow() => _p.setString('data', jsonEncode(_toMap()));

  void setFonts({String? quran, String? ui}) {
    if (quran != null) {
      quranFontId = quran;
      quranFont = quran;
    }
    if (ui != null) uiFontId = ui;
    _save();
    notifyListeners();
  }

  void setHAdj(int v) {
    hAdj = v.clamp(-2, 2).toInt();
    _occList = null;
    _save();
    notifyListeners();
    _applyPrayer();
    _applyOcc();
  }

  void setAmoled(bool v) {
    amoled = v;
    _save();
    notifyListeners();
  }

  void finishOnboarding() {
    onboarded = true;
    _save();
    notifyListeners();
  }

  void addUz(String text, int n) {
    uz.add({'id': 'u${DateTime.now().millisecondsSinceEpoch}', 'm': text, 'n': n < 1 ? 1 : n});
    _save();
    notifyListeners();
  }

  void removeUz(String id) {
    uz.removeWhere((e) => e['id'] == id);
    _save();
    notifyListeners();
  }

  void toggleSeq() {
    seq = !seq;
    if (seq) {
      for (final i in ['subhan', 'hamd', 'akbar']) {
        session[i] = 0;
      }
      currentId = 'subhan';
    }
    _save();
    notifyListeners();
  }

  void setBookmark(int surah, double y, {bool notify = true}) {
    bmSurah = surah;
    bmY = y;
    _save();
    if (notify) notifyListeners();
  }

  void setReader({double? speed, double? fs}) {
    this.speed = speed ?? this.speed;
    this.fs = fs ?? this.fs;
    _save();
    notifyListeners();
  }

  Future<void> resetAll() async {
    session = {};
    history = {};
    lifetime = {};
    await _save();
    notifyListeners();
  }

  // ───── التخزين ─────
  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    final raw = _p.getString('data');
    if (raw == null) return;
    try {
      final m = jsonDecode(raw) as Map<String, dynamic>;
      Map<String, int> ints(String k) =>
          Map<String, int>.from((m[k] ?? {}) as Map);
      customAzkar = ((m['custom'] ?? []) as List)
          .map((e) => Dhikr(e['id'], e['text'], e['target'], custom: true))
          .toList();
      currentId = m['current'] ?? currentId;
      session = ints('session');
      history = ints('history');
      lifetime = ints('lifetime');
      targets = ints('targets');
      az = ints('az');
      hd = ((m['hd'] ?? {}) as Map).map((k, v) => MapEntry(k as String, Map<String, int>.from(v as Map)));
      uz = List<Map<String, dynamic>>.from(((m['uz'] ?? []) as List).map((e) => Map<String, dynamic>.from(e as Map)));
      digits = m['dig'] ?? 'ar';
      useArabicDigits = digits == 'ar';
      onboarded = m['ob'] ?? lifetime.isNotEmpty;
      quickNotif = m['qn'] ?? false;
      hAdj = m['hadj'] ?? 0;
      amoled = m['amo'] ?? false;
      quranFontId = m['fq'] ?? 'Amiri';
      quranFont = quranFontId;
      uiFontId = m['fu'] ?? '';
      pr = Map<String, int>.from((m['pr'] ?? {}) as Map);
      khOn = m['kho'] ?? false;
      khDays = m['khd'] ?? 30;
      khStart = m['khs'] as String?;
      khDone = List<int>.from((m['khx'] ?? []) as List);
      khCount = m['khc'] ?? 0;
      khRem = m['khr'] ?? false;
      khRemH = m['khrh'] ?? 21;
      khRemM = m['khrm'] ?? 0;
      occNotify = m['occ'] ?? false;
      dailyGoal = m['goal'] ?? 100;
      haptics = m['haptics'] ?? true;
      sound = m['sound'] ?? false;
      dark = m['dark'] ?? true;
      reminder = m['reminder'] ?? false;
      remHour = m['rh'] ?? 8;
      remMin = m['rm'] ?? 0;
      seq = m['seq'] ?? false;
      speed = ((m['sp'] ?? 3) as num).toDouble();
      fs = ((m['fs'] ?? 30) as num).toDouble();
      bmSurah = m['bs'] ?? 0;
      bmY = ((m['by'] ?? 0) as num).toDouble();
      azMOn = m['azmo'] ?? false;
      azEOn = m['azeo'] ?? false;
      azMH = m['azmh'] ?? 6;
      azMM = m['azmm'] ?? 0;
      azEH = m['azeh'] ?? 17;
      azEM = m['azem'] ?? 30;
      pCity = m['pc'] ?? 0;
      pMethod = m['pm'] ?? 0;
      pAsr = m['pasr'] ?? 1;
      pLat = ((m['plat'] ?? 21.4225) as num).toDouble();
      pLng = ((m['plng'] ?? 39.8262) as num).toDouble();
      pTz = m['ptz'] ?? 'Asia/Riyadh';
      pName = m['pname'] ?? 'مكة المكرمة';
      pAdj = List<int>.from(m['padj'] ?? [0, 0, 0, 0, 0, 0]);
      p24 = m['p24'] ?? false;
      pNotify = m['pn'] ?? false;
      pPre = m['ppre'] ?? 0;
      pIqama = m['piqo'] ?? false;
      pIq = List<int>.from((m['piq'] ?? [25, 15, 15, 10, 15]) as List);
      wRem = m['wrem'] ?? false;
      wTimes = List<int>.from((m['wt'] ?? [600, 900]) as List);
      pRam = m['pram'] ?? true;
      pAdhan = m['padhan'] ?? false;
      marks = [for (final e in (m['marks'] ?? []) as List) List<int>.from(e as List)];
      themeMode = m['tm'] ?? ((m['dark'] ?? true) ? 'dark' : 'light');
      palette = m['pal'] ?? 0;
      accent = m['acc'] as int?;
    } catch (_) {}
  }

  Map<String, dynamic> _toMap() => {
        'custom': customAzkar.map((d) => d.toJson()).toList(),
        'current': currentId,
        'session': session,
        'history': history,
        'lifetime': lifetime,
        'targets': targets,
        'az': az,
        'hd': hd,
        'uz': uz,
        'dig': digits,
        'ob': onboarded,
        'qn': quickNotif,
        'hadj': hAdj,
        'amo': amoled,
        'fq': quranFontId,
        'fu': uiFontId,
        'pr': pr,
        'kho': khOn,
        'khd': khDays,
        'khs': khStart,
        'khx': khDone,
        'khc': khCount,
        'khr': khRem,
        'khrh': khRemH,
        'khrm': khRemM,
        'occ': occNotify,
        'goal': dailyGoal,
        'haptics': haptics,
        'sound': sound,
        'dark': dark,
        'reminder': reminder,
        'rh': remHour,
        'rm': remMin,
        'seq': seq,
        'sp': speed,
        'fs': fs,
        'bs': bmSurah,
        'by': bmY,
        'azmo': azMOn,
        'azeo': azEOn,
        'azmh': azMH,
        'azmm': azMM,
        'azeh': azEH,
        'azem': azEM,
        'pc': pCity,
        'pm': pMethod,
        'pasr': pAsr,
        'plat': pLat,
        'plng': pLng,
        'ptz': pTz,
        'pname': pName,
        'padj': pAdj,
        'p24': p24,
        'pn': pNotify,
        'ppre': pPre,
        'piqo': pIqama,
        'piq': pIq,
        'wrem': wRem,
        'wt': wTimes,
        'pram': pRam,
        'padhan': pAdhan,
        'marks': marks,
        'tm': themeMode,
        'pal': palette,
        'acc': accent,
      };

  Future<void> _save() {
    if (quickNotif) _showQuick();
    return _p.setString('data', jsonEncode(_toMap()));
  }
}
