import 'package:flutter_test/flutter_test.dart';
import 'package:tasabeeh/quran.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('المصحف الكامل: ١١٤ سورة و٦٢٣٦ آية', () async {
    await Quran.load();
    expect(Quran.full, isTrue);
    expect(Quran.data.length, 114);
    expect(Quran.data.values.fold<int>(0, (a, l) => a + l.length), 6236);
    expect(Quran.data[1]!.length, 7);
    expect(Quran.data[2]!.length, 286);
    expect(Quran.data[114]!.length, 6);
  });

  test('لا آية فارغة ولا بسملة مكررة في أول السور', () async {
    await Quran.load();
    for (final e in Quran.data.entries) {
      for (final v in e.value) {
        expect(v.trim().isNotEmpty, isTrue, reason: 'سورة ${e.key}');
      }
      if (e.key != 1) {
        expect(e.value.first.startsWith('بِسْمِ ٱللَّهِ'), isFalse, reason: 'سورة ${e.key}');
      }
    }
  });
}
