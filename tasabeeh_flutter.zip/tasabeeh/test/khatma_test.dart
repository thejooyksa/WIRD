import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tasabeeh/occasions.dart';
import 'package:tasabeeh/quran.dart';
import 'package:tasabeeh/state.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  int idx(int s, int a) {
    var c = 0;
    for (var n = 1; n < s; n++) {
      c += Quran.data[n]!.length;
    }
    return c + a - 1;
  }

  test('أوراد الختمة متصلة وتغطي ٦٢٣٦ آية', () async {
    await Quran.load();
    for (final days in [15, 30, 90]) {
      var prev = -1;
      for (var d = 1; d <= days; d++) {
        final r = Quran.khRange(d, days);
        expect(idx(r.$1.$1, r.$1.$2), prev + 1, reason: 'يوم $d من $days');
        prev = idx(r.$2.$1, r.$2.$2);
      }
      expect(prev, Quran.totalVerses - 1);
    }
    final first = Quran.khRange(1, 30);
    expect(first.$1, (1, 1));
    expect(first.$2, (2, 200));
  });

  test('مسار الختمة: بدء وإنجاز وإكمال وختمة جديدة', () async {
    await Quran.load();
    SharedPreferences.setMockInitialValues({});
    final s = AppState();
    await s.load();
    s.khSetDays(15);
    s.khStartPlan();
    expect(s.khOn, isTrue);
    expect(s.khNext, 1);
    s.khMarkDone(1);
    expect(s.khNext, 2);
    for (var d = 1; d <= 15; d++) {
      s.khMarkDone(d);
    }
    expect(s.khNext, 0);
    s.khFinish();
    expect(s.khCount, 1);
    expect(s.khOn, isFalse);
  });

  test('متابعة الصلوات والالتزام المتواصل', () async {
    SharedPreferences.setMockInitialValues({});
    final s = AppState();
    await s.load();
    for (var i = 0; i < 5; i++) {
      s.togglePrayer(0, i);
    }
    expect(s.prMask(0), 31);
    expect(s.prStreak, 1);
    s.togglePrayer(0, 2);
    expect(s.prCount(s.prMask(0)), 4);
    final s2 = AppState();
    await s2.load();
    expect(s2.prCount(s2.prMask(0)), 4);
  });

  test('المناسبات الهجرية القادمة مرتبة وغير فارغة', () {
    final from = DateTime(2026, 11, 8);
    final list = upcomingOccasions(from, max: 6);
    expect(list.length, 6);
    for (var i = 0; i < list.length; i++) {
      expect(list[i].daysFrom(from) >= 0, isTrue);
      expect(list[i].name.isNotEmpty, isTrue);
      if (i > 0) expect(list[i].date.isBefore(list[i - 1].date), isFalse);
    }
  });
}
