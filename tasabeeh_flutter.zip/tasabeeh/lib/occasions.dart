import 'package:hijri/hijri_calendar.dart';

const hijriMonths = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];

class Occasion {
  final DateTime date;
  final String name, hint;
  final int hMonth, hDay;
  const Occasion(this.date, this.name, this.hint, this.hMonth, this.hDay);

  int daysFrom(DateTime from) =>
      DateTime(date.year, date.month, date.day).difference(DateTime(from.year, from.month, from.day)).inDays;
}

/// (شهر هجري أو 0 لكل شهر، يوم، الاسم، تلميح)
const _occ = [
  (1, 1, 'رأس السنة الهجرية', ''),
  (1, 9, 'تاسوعاء', 'يُسنّ صيامه مع عاشوراء'),
  (1, 10, 'عاشوراء', 'يُسنّ صيامه'),
  (0, 13, 'أيام البيض (١٣ و١٤ و١٥)', 'يُسنّ صيامها من كل شهر هجري'),
  (9, 1, 'بداية رمضان', ''),
  (9, 21, 'العشر الأواخر من رمضان', 'التمس ليلة القدر'),
  (10, 1, 'عيد الفطر', ''),
  (10, 2, 'ستة أيام من شوال', 'لمن أتمّ صيام رمضان'),
  (12, 1, 'العشر الأوائل من ذي الحجة', ''),
  (12, 9, 'يوم عرفة', 'يُسنّ صيامه لغير الحاج'),
  (12, 10, 'عيد الأضحى', ''),
  (12, 11, 'أيام التشريق', ''),
];

/// المناسبات القادمة بحسب تقويم أم القرى (قد يختلف يومًا عن رؤية بلدك)
List<Occasion> upcomingOccasions(DateTime from, {int days = 420, int max = 5, int adj = 0}) {
  final out = <Occasion>[];
  final start = DateTime(from.year, from.month, from.day, 12);
  for (var i = 0; i < days && out.length < max; i++) {
    final d = start.add(Duration(days: i));
    final h = HijriCalendar.fromDate(d.add(Duration(days: adj)));
    for (final o in _occ) {
      if ((o.$1 == h.hMonth || o.$1 == 0) && o.$2 == h.hDay) out.add(Occasion(d, o.$3, o.$4, h.hMonth, h.hDay));
    }
  }
  return out.take(max).toList();
}
