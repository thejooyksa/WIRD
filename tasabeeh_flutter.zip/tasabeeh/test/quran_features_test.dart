import 'package:flutter_test/flutter_test.dart';
import 'package:tasabeeh/quran.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('البحث يتجاهل التشكيل ويجد آية الكرسي', () async {
    await Quran.load();
    final r = Quran.search('الحي القيوم');
    expect(r.any((x) => x.$1 == 2 && x.$2 == 255), isTrue);
    final sn = Quran.snippet(r.first.$1, r.first.$2, r.first.$3, r.first.$4);
    expect(sn.$2.isNotEmpty, isTrue);
  });

  test('الأجزاء ٣٠ مرتبة وبداياتها داخل السور', () async {
    await Quran.load();
    expect(juzStarts.length, 30);
    for (final j in juzStarts) {
      expect(Quran.data[j[0]]!.length >= j[1], isTrue);
    }
    for (var i = 1; i < 30; i++) {
      final a = juzStarts[i - 1], b = juzStarts[i];
      expect(b[0] * 1000 + b[1] > a[0] * 1000 + a[1], isTrue);
    }
  });
}
