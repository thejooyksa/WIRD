import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tasabeeh/state.dart';
import 'package:tasabeeh/theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  tearDown(() => quranFont = 'Amiri');

  test('اختيار الخطوط وحفظها وتحديث المتغير العام', () async {
    SharedPreferences.setMockInitialValues({});
    final s = AppState();
    await s.load();
    expect(quranFont, 'Amiri');
    s.setFonts(quran: 'Lateef', ui: 'Cairo');
    expect(quranFont, 'Lateef');
    quranFont = 'Amiri';
    final s2 = AppState();
    await s2.load();
    expect(s2.quranFontId, 'Lateef');
    expect(s2.uiFontId, 'Cairo');
    expect(quranFont, 'Lateef');
  });

  test('خيارات الخطوط فريدة وغير فارغة', () {
    expect(quranFonts.map((f) => f.family).toSet().length, quranFonts.length);
    expect(uiFonts.map((f) => f.family).toSet().length, uiFonts.length);
    expect(quranFonts.every((f) => f.family.isNotEmpty && f.label.isNotEmpty), isTrue);
  });

  test('الثيم يقبل خط الواجهة', () {
    final t = buildTheme(Brightness.dark, 0, null, font: 'Cairo');
    expect(t.textTheme.bodyMedium?.fontFamily, 'Cairo');
    final d = buildTheme(Brightness.dark, 0, null);
    expect(d.textTheme.bodyMedium?.fontFamily == 'Cairo', isFalse);
  });
}
