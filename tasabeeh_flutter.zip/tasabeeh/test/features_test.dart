import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tasabeeh/main.dart';
import 'package:tasabeeh/state.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

Future<AppState> fresh() async {
  SharedPreferences.setMockInitialValues({});
  final s = AppState();
  await s.load();
  s.haptics = false;
  return s;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() {
    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Asia/Riyadh'));
  });
  tearDown(() => useArabicDigits = true);

  test('سجل التسبيح اليومي لكل ذكر مع التراجع', () async {
    final s = await fresh();
    for (var i = 0; i < 4; i++) {
      s.tap();
    }
    s.undo();
    final log = s.todayLog();
    expect(log.length, 1);
    expect(log.first.key, 'subhan');
    expect(log.first.value, 3);
    expect(s.shareText().contains(ar(3)), isTrue);
  });

  test('قائمة أذكاري: إضافة وحذف وحفظ', () async {
    final s = await fresh();
    s.addUz('اللهم اغفر لي', 3);
    s.addUz('سبحان الله', 0);
    expect(s.uz.length, 2);
    expect(s.uz[1]['n'], 1);
    final s2 = AppState();
    await s2.load();
    expect(s2.uz.length, 2);
    s2.removeUz(s2.uz.first['id'] as String);
    expect(s2.uz.length, 1);
  });

  test('الأرقام: عربية أو إنجليزية', () async {
    final s = await fresh();
    expect(ar(12), '١٢');
    s.setDigits('en');
    expect(ar(12), '12');
    s.setDigits('ar');
    expect(ar(12), '١٢');
  });

  testWidgets('شاشة الترحيب تظهر أول مرة وتنتهي بالتخطي', (tester) async {
    final s = (await tester.runAsync(fresh))!;
    expect(s.onboarded, isFalse);
    await tester.pumpWidget(TasabeehApp(s));
    await tester.pump();
    expect(find.text('أهلًا بك في تسابيح'), findsOneWidget);
    await tester.tap(find.text('تخطي'));
    await tester.pump();
    expect(s.onboarded, isTrue);
    await tester.pumpWidget(const SizedBox());
  });

  test('العدّ السريع: إعادة التحميل تلتقط عدّ الخلفية', () async {
    final a = await fresh();
    a.tap(feedback: false);
    final b = AppState();
    await b.load();
    b.tap(feedback: false);
    await b.saveNow();
    await a.reload();
    expect(a.sessionCount, 2);
    expect(a.today, 2);
  });
}
