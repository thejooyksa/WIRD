import 'package:flutter/material.dart';

/// bg الخلفية، surf البطاقات، line الحدود، ink النص، mut النص الثانوي، primary لون التمييز
class PalColors {
  final int bg, surf, line, ink, mut, primary;
  const PalColors(this.bg, this.surf, this.line, this.ink, this.mut, this.primary);
}

class AppPalette {
  final String name;
  final PalColors dark, light;
  const AppPalette(this.name, this.dark, this.light);
}

const palettes = [
  AppPalette('زمردي', PalColors(0xFF07160F, 0xFF10281D, 0xFF2F4A3A, 0xFFF1EAD6, 0xFFA3B3A6, 0xFFD9B765), PalColors(0xFFF6F0E0, 0xFFFFFAF0, 0xFFD8C9A3, 0xFF1A2A21, 0xFF6A6A55, 0xFF9A7A35)),
  AppPalette('أزرق ملكي', PalColors(0xFF070F1E, 0xFF101D36, 0xFF27406B, 0xFFE9EEF9, 0xFF9FB0CC, 0xFF6FB1F2), PalColors(0xFFEEF3FB, 0xFFFFFFFF, 0xFFC9D7EE, 0xFF14213A, 0xFF5A6A85, 0xFF2B6CB0)),
  AppPalette('بنفسجي', PalColors(0xFF120A1F, 0xFF1C1030, 0xFF3E2A5E, 0xFFF0E9FB, 0xFFB3A3CC, 0xFFC39BF2), PalColors(0xFFF6F0FC, 0xFFFFFFFF, 0xFFDCCAF0, 0xFF2A1744, 0xFF6F5A8A, 0xFF7A4CB8)),
  AppPalette('عنابي', PalColors(0xFF1C0A10, 0xFF2A101A, 0xFF5E2A38, 0xFFF8E9EC, 0xFFCBA5AD, 0xFFE89AAA), PalColors(0xFFFBF0F1, 0xFFFFFFFF, 0xFFEFCBD2, 0xFF3A1620, 0xFF8A5A64, 0xFFA33A52)),
  AppPalette('رمادي فحمي', PalColors(0xFF0F0F10, 0xFF17171A, 0xFF34343A, 0xFFECECEC, 0xFFA0A0A6, 0xFFD8D8DE), PalColors(0xFFF4F4F5, 0xFFFFFFFF, 0xFFD6D6DA, 0xFF1B1B1F, 0xFF666666, 0xFF4A4A52)),
  AppPalette('رملي دافئ', PalColors(0xFF1A1410, 0xFF251C14, 0xFF4D3B28, 0xFFF6ECDD, 0xFFBBA98F, 0xFFE3B565), PalColors(0xFFF8F0E2, 0xFFFFFAF0, 0xFFE0CFA8, 0xFF2B2014, 0xFF7A6648, 0xFF9A6A1E)),
];

/// ألوان تمييز جاهزة (يمكن للمستخدم اختيار لون آخر بالمنزلقات)
const accentPresets = [0xFFD9B765, 0xFFF2A65A, 0xFFE5546B, 0xFFE87BB5, 0xFF9B6BD6, 0xFF6C7BE0, 0xFF4A90E2, 0xFF2EC4B6, 0xFF4CAF7A];

Color mixColor(Color a, Color b, double t) => Color.lerp(a, b, t)!;

class FontOption {
  final String family, label;
  const FontOption(this.family, this.label);
}

/// خطوط القرآن والأذكار (تُضمَّن عبر tool/setup_fonts.py؛ بدون الملف يُستعمل الخط الافتراضي)
const quranFonts = [
  FontOption('Amiri', 'أميري'),
  FontOption('ScheherazadeNew', 'شهرزاد (Scheherazade)'),
  FontOption('NotoNaskhArabic', 'نسخ (Noto Naskh)'),
  FontOption('Lateef', 'لطيف (Lateef)'),
  FontOption('Roboto', 'خط النظام'),
];

const uiFonts = [
  FontOption('', 'خط النظام (الافتراضي)'),
  FontOption('Cairo', 'القاهرة (Cairo)'),
  FontOption('Tajawal', 'تجوال (Tajawal)'),
  FontOption('NotoSansArabic', 'Noto Sans Arabic'),
];

ThemeData buildTheme(Brightness b, int pal, int? accent, {String? font, bool amoled = false}) {
  final d = b == Brightness.dark;
  final p = palettes[pal.clamp(0, palettes.length - 1)];
  final c = d ? p.dark : p.light;
  var primary = Color(c.primary);
  if (accent != null) {
    final a = Color(accent);
    primary = d ? mixColor(a, Colors.white, .15) : mixColor(a, Colors.black, .1);
  }
  final onPrimary = primary.computeLuminance() > .5 ? const Color(0xFF1A1405) : Colors.white;
  final bg = Color(d && amoled ? 0xFF000000 : c.bg), surf = Color(d && amoled ? 0xFF0A0A0A : c.surf);
  final cs = ColorScheme.fromSeed(seedColor: primary, brightness: b).copyWith(
    primary: primary,
    onPrimary: onPrimary,
    surface: surf,
    onSurface: Color(c.ink),
    onSurfaceVariant: Color(c.mut),
    secondaryContainer: surf,
    outlineVariant: Color(c.line),
  );
  return ThemeData(
    useMaterial3: true,
    fontFamily: (font == null || font.isEmpty) ? null : font,
    colorScheme: cs,
    scaffoldBackgroundColor: bg,
    appBarTheme: AppBarTheme(backgroundColor: bg, foregroundColor: primary, centerTitle: true),
    navigationBarTheme: NavigationBarThemeData(backgroundColor: surf, indicatorColor: primary.withOpacity(.2)),
  );
}
