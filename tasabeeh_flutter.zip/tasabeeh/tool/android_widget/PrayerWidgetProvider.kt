package __PKG__

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.SharedPreferences
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetProvider

/** ويدجت الصلاة القادمة: يقرأ الأوقات التي يحفظها التطبيق ويعرض أقرب وقت قادم. */
class PrayerWidgetProvider : HomeWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
        widgetData: SharedPreferences
    ) {
        val raw = widgetData.getString("prayers", "") ?: ""
        val city = widgetData.getString("city", "") ?: ""
        val now = System.currentTimeMillis()
        var name = "افتح التطبيق"
        var time = "--:--"
        var left = ""
        for (item in raw.split(";")) {
            val p = item.split("|")
            if (p.size < 3) continue
            val t = p[1].toLongOrNull() ?: continue
            if (t > now) {
                name = p[0]
                time = p[2]
                val mins = (t - now) / 60000
                left = "بعد " + (mins / 60) + " س و " + (mins % 60) + " د"
                break
            }
        }
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val pi = PendingIntent.getActivity(
            context, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        for (id in appWidgetIds) {
            val views = RemoteViews(context.packageName, R.layout.prayer_widget)
            views.setTextViewText(R.id.w_city, city)
            views.setTextViewText(R.id.w_name, name)
            views.setTextViewText(R.id.w_time, time)
            views.setTextViewText(R.id.w_left, left)
            views.setOnClickPendingIntent(R.id.w_root, pi)
            appWidgetManager.updateAppWidget(id, views)
        }
    }
}
