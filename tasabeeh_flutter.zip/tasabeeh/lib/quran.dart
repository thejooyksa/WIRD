import 'package:flutter/services.dart';

const surahNames = [
  'الفاتحة','البقرة','آل عمران','النساء','المائدة','الأنعام','الأعراف','الأنفال','التوبة','يونس','هود','يوسف','الرعد','إبراهيم','الحجر','النحل','الإسراء','الكهف','مريم','طه','الأنبياء','الحج','المؤمنون','النور','الفرقان','الشعراء','النمل','القصص','العنكبوت','الروم','لقمان','السجدة','الأحزاب','سبأ','فاطر','يس','الصافات','ص','الزمر','غافر','فصلت','الشورى','الزخرف','الدخان','الجاثية','الأحقاف','محمد','الفتح','الحجرات','ق','الذاريات','الطور','النجم','القمر','الرحمن','الواقعة','الحديد','المجادلة','الحشر','الممتحنة','الصف','الجمعة','المنافقون','التغابن','الطلاق','التحريم','الملك','القلم','الحاقة','المعارج','نوح','الجن','المزمل','المدثر','القيامة','الإنسان','المرسلات','النبأ','النازعات','عبس','التكوير','الانفطار','المطففين','الانشقاق','البروج','الطارق','الأعلى','الغاشية','الفجر','البلد','الشمس','الليل','الضحى','الشرح','التين','العلق','القدر','البينة','الزلزلة','العاديات','القارعة','التكاثر','العصر','الهمزة','الفيل','قريش','الماعون','الكوثر','الكافرون','النصر','المسد','الإخلاص','الفلق','الناس',
];

// نماذج قصيرة للتجربة فقط، تُستبدل بالمصحف الكامل عند وضع ملف Tanzil في assets/quran
const _sample = <int, List<String>>{
  1: ['بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', 'ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ', 'ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', 'مَٰلِكِ يَوْمِ ٱلدِّينِ', 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ', 'ٱهْدِنَا ٱلصِّرَٰطَ ٱلْمُسْتَقِيمَ', 'صِرَٰطَ ٱلَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ ٱلْمَغْضُوبِ عَلَيْهِمْ وَلَا ٱلضَّآلِّينَ'],
  103: ['وَٱلْعَصْرِ', 'إِنَّ ٱلْإِنسَٰنَ لَفِى خُسْرٍ', 'إِلَّا ٱلَّذِينَ ءَامَنُوا۟ وَعَمِلُوا۟ ٱلصَّٰلِحَٰتِ وَتَوَاصَوْا۟ بِٱلْحَقِّ وَتَوَاصَوْا۟ بِٱلصَّبْرِ'],
  108: ['إِنَّآ أَعْطَيْنَٰكَ ٱلْكَوْثَرَ', 'فَصَلِّ لِرَبِّكَ وَٱنْحَرْ', 'إِنَّ شَانِئَكَ هُوَ ٱلْأَبْتَرُ'],
  112: ['قُلْ هُوَ ٱللَّهُ أَحَدٌ', 'ٱللَّهُ ٱلصَّمَدُ', 'لَمْ يَلِدْ وَلَمْ يُولَدْ', 'وَلَمْ يَكُن لَّهُۥ كُفُوًا أَحَدٌۢ'],
  113: ['قُلْ أَعُوذُ بِرَبِّ ٱلْفَلَقِ', 'مِن شَرِّ مَا خَلَقَ', 'وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ', 'وَمِن شَرِّ ٱلنَّفَّٰثَٰتِ فِى ٱلْعُقَدِ', 'وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ'],
  114: ['قُلْ أَعُوذُ بِرَبِّ ٱلنَّاسِ', 'مَلِكِ ٱلنَّاسِ', 'إِلَٰهِ ٱلنَّاسِ', 'مِن شَرِّ ٱلْوَسْوَاسِ ٱلْخَنَّاسِ', 'ٱلَّذِى يُوَسْوِسُ فِى صُدُورِ ٱلنَّاسِ', 'مِنَ ٱلْجِنَّةِ وَٱلنَّاسِ'],
};

class Quran {
  static Map<int, List<String>> data = Map.of(_sample);
  static bool full = false;

  static int get totalVerses => data.values.fold(0, (a, l) => a + l.length);

  /// الآية رقم index (من ٠) في المصحف كله ← (السورة، الآية)
  static (int, int) verseAt(int index) {
    var c = 0;
    for (var n = 1; n <= 114; n++) {
      final l = data[n]?.length ?? 0;
      if (index < c + l) return (n, index - c + 1);
      c += l;
    }
    return (114, data[114]?.length ?? 1);
  }

  /// ورد اليوم d من ختمة مدتها days (تقسيم متساوٍ على آيات المصحف): (البداية، النهاية)
  static ((int, int), (int, int)) khRange(int d, int days) {
    final n = totalVerses;
    final a = ((d - 1) * n) ~/ days, b = (d * n) ~/ days - 1;
    return (verseAt(a), verseAt(b));
  }

  static String _nz(String w) => w
      .replaceAll(RegExp('[\u064B-\u065F\u0670\u06D6-\u06ED\u0640]'), '')
      .replaceAll('ٱ', 'ا');

  /// يقرأ assets/quran/quran-uthmani.txt بصيغة: سورة|آية|نص
  static Future<void> load() async {
    try {
      final raw = (await rootBundle.loadString('assets/quran/quran-uthmani.txt')).replaceFirst('\uFEFF', '');
      final q = <int, List<String>>{};
      for (final l in raw.split(RegExp(r'\r?\n'))) {
        if (l.isEmpty || l.startsWith('#')) continue;
        final p = l.split('|');
        if (p.length < 3) continue;
        final s = int.tryParse(p[0]), a = int.tryParse(p[1]);
        if (s == null || a == null || a < 1) continue;
        final list = q.putIfAbsent(s, () => []);
        while (list.length < a) {
          list.add('');
        }
        list[a - 1] = p.sublist(2).join('|').trim();
      }
      // ملف Tanzil يضع البسملة في بداية أول آية من كل سورة (عدا الفاتحة والتوبة)
      for (final e in q.entries) {
        if (e.key == 1 || e.key == 9 || e.value.isEmpty) continue;
        final w = e.value[0].split(' ');
        if (w.length > 4 && _nz(w.take(4).join('')) == 'بسماللهالرحمنالرحيم') {
          e.value[0] = w.skip(4).join(' ');
        }
      }
      _nc = null;
      if (q.isNotEmpty) {
        data = {..._sample, ...q};
        full = q.length >= 114;
      }
    } catch (_) {}
  }

  // ───── البحث ─────
  static Map<int, List<(String, List<int>)>>? _nc;

  /// يزيل التشكيل ويوحّد الألفات والياء والهاء ويرجع (النص المبسّط، فهرس كل حرف في الأصل)
  static (String, List<int>) normMap(String s) {
    final o = StringBuffer();
    final m = <int>[];
    for (var i = 0; i < s.length; i++) {
      var c = s[i];
      final u = c.codeUnitAt(0);
      if ((u >= 0x064B && u <= 0x065F) || u == 0x0670 || (u >= 0x06D6 && u <= 0x06ED) || u == 0x0640) continue;
      c = 'ٱأإآ'.contains(c)
          ? 'ا'
          : c == 'ى'
              ? 'ي'
              : c == 'ة'
                  ? 'ه'
                  : c == 'ؤ'
                      ? 'و'
                      : c == 'ئ'
                          ? 'ي'
                          : c;
      o.write(c);
      m.add(i);
    }
    return (o.toString(), m);
  }

  /// نتائج البحث: (سورة، آية، موضع التطابق في النص المبسّط، طول التطابق)
  static List<(int, int, int, int)> search(String term) {
    final q = normMap(term.trim()).$1;
    if (q.length < 2) return [];
    _nc ??= {for (final e in data.entries) e.key: [for (final t in e.value) normMap(t)]};
    final keys = data.keys.toList()..sort();
    final r = <(int, int, int, int)>[];
    for (final n in keys) {
      final l = _nc![n]!;
      for (var i = 0; i < l.length; i++) {
        final idx = l[i].$1.indexOf(q);
        if (idx >= 0) r.add((n, i + 1, idx, q.length));
      }
    }
    return r;
  }

  /// مقتطف حول موضع التطابق: (قبل، المطابق، بعد)
  static (String, String, String) snippet(int n, int a, int idx, int len) {
    final t = data[n]![a - 1];
    final mp = _nc![n]![a - 1].$2;
    final s = mp[idx];
    final e = idx + len < mp.length ? mp[idx + len] : t.length;
    final s0 = s - 50 < 0 ? 0 : s - 50, e0 = e + 70 > t.length ? t.length : e + 70;
    return ('${s0 > 0 ? '… ' : ''}${t.substring(s0, s)}', t.substring(s, e), '${t.substring(e, e0)}${e0 < t.length ? ' …' : ''}');
  }
}

/// بداية كل جزء: [سورة، آية] (تحققت من نص Tanzil)
const juzStarts = [[1, 1], [2, 142], [2, 253], [3, 92], [4, 24], [4, 148], [5, 83], [6, 111], [7, 88], [8, 41], [9, 94], [11, 6], [12, 53], [15, 1], [17, 1], [18, 75], [21, 1], [23, 1], [25, 21], [27, 60], [29, 45], [33, 31], [36, 28], [39, 32], [41, 47], [46, 1], [51, 31], [58, 1], [67, 1], [78, 1]];
