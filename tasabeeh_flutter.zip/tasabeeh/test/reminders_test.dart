import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tasabeeh/prayer.dart';
import 'package:tasabeeh/state.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() {
    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Asia/Riyadh'));
  });

  test('فهرس الإقامة يطابق الصلوات الخمس', () {
    expect([0, 2, 3, 4, 5].map(iqamaIndex).toList(), [0, 1, 2, 3, 4]);
  });

  test('أوقات تذكير ورد الذكر: إضافة وحذف وحد أقصى ٤ وحفظ', () async {
    SharedPreferences.setMockInitialValues({});
    final s = AppState();
    await s.load();
    expect(s.wTimes.length, 2);
    s.addWTime(1200);
    s.addWTime(1200); // مكرر لا يُضاف
    s.addWTime(300);
    s.addWTime(400); // الخامس مرفوض
    expect(s.wTimes.length, 4);
    expect(s.wTimes, [...s.wTimes]..sort());
    s.removeWTime(0);
    expect(s.wTimes.length, 3);
    s.setWRem(true);
    final s2 = AppState();
    await s2.load();
    expect(s2.wRem, isTrue);
    expect(s2.wTimes, s.wTimes);
  });

  test('إعدادات الإقامة والتذكير قبل الصلاة تُحفظ ولا تسبب أخطاء الجدولة', () async {
    SharedPreferences.setMockInitialValues({});
    final s = AppState();
    await s.load();
    s.updatePrayer(() {
      s.pPre = 10;
      s.pIqama = true;
      s.pIq[0] = 30;
    });
    await Future<void>.delayed(const Duration(milliseconds: 50));
    final s2 = AppState();
    await s2.load();
    expect(s2.pPre, 10);
    expect(s2.pIqama, isTrue);
    expect(s2.pIq[0], 30);
    expect(s2.pIq.length, 5);
  });
}
