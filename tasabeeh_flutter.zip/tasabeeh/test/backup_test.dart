import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tasabeeh/state.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('نسخة احتياطية: تصدير ثم استيراد على جهاز جديد', () async {
    SharedPreferences.setMockInitialValues({});
    final a = AppState();
    await a.load();
    a.haptics = false;
    for (var i = 0; i < 3; i++) {
      a.tap();
    }
    a.toggleMark(2, 255);
    final json = a.exportJson();

    SharedPreferences.setMockInitialValues({});
    final b = AppState();
    await b.load();
    expect(await b.importJson(json), isTrue);
    expect(b.sessionCount, 3);
    expect(b.hasMark(2, 255), isTrue);
    expect(await b.importJson('نص غير صالح'), isFalse);
    expect(await b.importJson('{"app":"other"}'), isFalse);
  });
}
