#!/usr/bin/env python3
"""
ينزّل خطوطًا مفتوحة الرخصة (SIL OFL) من مستودع Google Fonts على GitHub ويضيفها إلى pubspec.yaml.
شغّله من جذر المشروع قبل flutter pub get:   python3 tool/setup_fonts.py
إن فشل تنزيل خط يُتجاهل ويستعمل التطبيق الخط الافتراضي بدلًا منه (لا يتوقف البناء).
"""
import os, re, urllib.parse, urllib.request

BASE = 'https://raw.githubusercontent.com/google/fonts/main/ofl/'
# اسم العائلة في التطبيق: [(مجلد الخط في المستودع، اسم الملف، الوزن)]
FONTS = {
    'Amiri': [('amiri', 'Amiri-Regular.ttf', 400), ('amiri', 'Amiri-Bold.ttf', 700)],
    'ScheherazadeNew': [('scheherazadenew', 'ScheherazadeNew-Regular.ttf', 400), ('scheherazadenew', 'ScheherazadeNew-Bold.ttf', 700)],
    'NotoNaskhArabic': [('notonaskharabic', 'NotoNaskhArabic[wght].ttf', 400)],
    'Lateef': [('lateef', 'Lateef-Regular.ttf', 400), ('lateef', 'Lateef-Bold.ttf', 700)],
    'Cairo': [('cairo', 'Cairo[slnt,wght].ttf', 400)],
    'Tajawal': [('tajawal', 'Tajawal-Regular.ttf', 400), ('tajawal', 'Tajawal-Bold.ttf', 700)],
    'NotoSansArabic': [('notosansarabic', 'NotoSansArabic[wdth,wght].ttf', 400)],
}


def fetch(url):
    with urllib.request.urlopen(url, timeout=40) as r:
        return r.read()


os.makedirs('assets/fonts', exist_ok=True)
os.makedirs('assets/licenses', exist_ok=True)
blocks, ok_fams, failed = [], [], []
for fam, files in FONTS.items():
    entries = []
    for d, fn, w in files:
        local = re.sub(r'[\[\],]', '_', fn)
        path = os.path.join('assets', 'fonts', local)
        try:
            if not os.path.exists(path):
                open(path, 'wb').write(fetch(BASE + d + '/' + urllib.parse.quote(fn)))
            entries.append((local, w))
        except Exception as e:  # noqa
            failed.append(fam + ': ' + fn + ' (' + str(e)[:50] + ')')
    if entries:
        ok_fams.append(fam)
        b = '    - family: %s\n      fonts:\n' % fam
        for local, w in entries:
            b += '        - asset: assets/fonts/%s\n' % local
            if w != 400:
                b += '          weight: %d\n' % w
        blocks.append(b)
        d0 = files[0][0]
        lic = os.path.join('assets', 'licenses', 'OFL-' + d0 + '.txt')
        if not os.path.exists(lic):
            try:
                open(lic, 'wb').write(fetch(BASE + d0 + '/OFL.txt'))
            except Exception:
                pass

pub = open('pubspec.yaml', encoding='utf-8').read()
pub = re.sub(r'  # <fonts-generated>.*?  # </fonts-generated>\n', '', pub, flags=re.S)
if blocks:
    gen = '  # <fonts-generated>\n  fonts:\n' + ''.join(blocks) + '  # </fonts-generated>\n'
    pub = pub.replace('  uses-material-design: true\n', '  uses-material-design: true\n' + gen, 1)
open('pubspec.yaml', 'w', encoding='utf-8').write(pub)
print('الخطوط المضافة:', ', '.join(ok_fams) or 'لا شيء')
if failed:
    print('تعذّر تنزيل:', *failed, sep='\n - ')
