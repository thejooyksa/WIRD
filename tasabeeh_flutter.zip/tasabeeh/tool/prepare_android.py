#!/usr/bin/env python3
"""
يجهّز مشروع أندرويد المولَّد بـ flutter create:
أيقونات، صلاحيات، مستقبلات الإشعارات، اسم التطبيق، التوقيع، desugaring.
شغّله من جذر المشروع:  python3 tool/prepare_android.py
"""
import os, re, shutil, sys

ROOT = os.getcwd()
APP = os.path.join(ROOT, 'android', 'app')
MAIN = os.path.join(APP, 'src', 'main')
issues = []

def rd(p):
    return open(p, encoding='utf-8').read()

def wr(p, s):
    open(p, 'w', encoding='utf-8').write(s)

if not os.path.isdir(APP):
    sys.exit('لم أجد android/app. شغّل أولًا: flutter create . --org com.yourname --project-name tasabeeh --platforms android')

# ── 1) الأيقونات ──
src, dst = os.path.join(ROOT, 'tool', 'android_res'), os.path.join(MAIN, 'res')
for r, _, fs in os.walk(dst):
    for f in fs:
        if f.startswith('ic_launcher') and f.endswith('.webp'):
            os.remove(os.path.join(r, f))
for r, _, fs in os.walk(src):
    for f in fs:
        t = os.path.join(dst, os.path.relpath(os.path.join(r, f), src))
        os.makedirs(os.path.dirname(t), exist_ok=True)
        shutil.copy(os.path.join(r, f), t)
print('OK  الأيقونات')

# ── 2) AndroidManifest ──
mp = os.path.join(MAIN, 'AndroidManifest.xml')
m = rd(mp)
perms = '''
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>'''
receivers = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver"/>
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
'''
if 'POST_NOTIFICATIONS' not in m:
    m = re.sub(r'(<manifest[^>]*>)', lambda x: x.group(1) + perms, m, 1)
if 'ScheduledNotificationReceiver' not in m:
    m = m.replace('</application>', receivers + '    </application>', 1)
m = re.sub(r'android:label="[^"]*"', 'android:label="تسابيح"', m, 1)
if 'roundIcon' not in m:
    m = m.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/ic_launcher"\n        android:roundIcon="@mipmap/ic_launcher_round"', 1)
wr(mp, m)
print('OK  AndroidManifest.xml')

# ── 3) Gradle ──
kts, grv = os.path.join(APP, 'build.gradle.kts'), os.path.join(APP, 'build.gradle')

def patch_kts(s):
    if 'keystoreProperties' in s:
        return s
    if 'import java.util.Properties' not in s:
        s = 'import java.io.FileInputStream\nimport java.util.Properties\n\n' + s
    load = '''
val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}
'''
    s, n1 = re.subn(r'(plugins \{.*?\n\}\n)', lambda x: x.group(1) + load, s, 1, flags=re.S)
    s, n2 = re.subn(r'compileOptions \{', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', s, 1)
    signing = '''    signingConfigs {
        create("release") {
            if (keystorePropertiesFile.exists()) {
                keyAlias = keystoreProperties["keyAlias"] as String
                keyPassword = keystoreProperties["keyPassword"] as String
                storeFile = file(keystoreProperties["storeFile"] as String)
                storePassword = keystoreProperties["storePassword"] as String
            }
        }
    }

    buildTypes {'''
    s, n3 = re.subn(r'buildTypes \{', signing, s, 1)
    s, n4 = re.subn(r'signingConfig\s*=\s*signingConfigs\.getByName\("debug"\)',
                    'signingConfig = if (keystorePropertiesFile.exists()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")', s, 1)
    s += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    if not all([n1, n2, n3, n4]):
        issues.append('build.gradle.kts: بعض التعديلات لم تُطبَّق (%s). طبّقها يدويًا حسب README_RELEASE_AR.md' % [n1, n2, n3, n4])
    return s

def patch_groovy(s):
    if 'keystoreProperties' in s:
        return s
    load = '''
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}
'''
    s, n1 = re.subn(r'(plugins \{.*?\n\}\n)', lambda x: x.group(1) + load, s, 1, flags=re.S)
    s, n2 = re.subn(r'compileOptions \{', 'compileOptions {\n        coreLibraryDesugaringEnabled true', s, 1)
    signing = '''    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
                storeFile file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
            }
        }
    }

    buildTypes {'''
    s, n3 = re.subn(r'buildTypes \{', signing, s, 1)
    s, n4 = re.subn(r'signingConfig\s*=?\s*signingConfigs\.debug',
                    'signingConfig keystorePropertiesFile.exists() ? signingConfigs.release : signingConfigs.debug', s, 1)
    s += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
    if not all([n1, n2, n3, n4]):
        issues.append('build.gradle: بعض التعديلات لم تُطبَّق (%s). طبّقها يدويًا حسب README_RELEASE_AR.md' % [n1, n2, n3, n4])
    return s

if os.path.exists(kts):
    wr(kts, patch_kts(rd(kts)))
    gp = kts
elif os.path.exists(grv):
    wr(grv, patch_groovy(rd(grv)))
    gp = grv
else:
    sys.exit('لم أجد ملف build.gradle للتطبيق')
print('OK ', os.path.basename(gp))

# ── 4) ويدجت الصلاة (Kotlin + مستقبل في المانيفست) ──
ns = re.search(r'namespace\s*=?\s*["\']([^"\']+)["\']', rd(gp))
if ns:
    pkg = ns.group(1)
    kdir = os.path.join(MAIN, 'kotlin', *pkg.split('.'))
    os.makedirs(kdir, exist_ok=True)
    wr(os.path.join(kdir, 'PrayerWidgetProvider.kt'), rd(os.path.join(ROOT, 'tool', 'android_widget', 'PrayerWidgetProvider.kt')).replace('__PKG__', pkg))
    m = rd(mp)
    if 'PrayerWidgetProvider' not in m:
        rcv = '''
        <receiver android:name=".PrayerWidgetProvider" android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE"/>
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/prayer_widget_info"/>
        </receiver>
'''
        wr(mp, m.replace('</application>', rcv + '    </application>', 1))
    print('OK  ويدجت الصلاة (' + pkg + ')')
else:
    issues.append('تعذّر تحديد namespace لإضافة الويدجت. انسخ tool/android_widget/PrayerWidgetProvider.kt يدويًا واستبدل __PKG__.')

if re.search(r'com\.example', rd(gp)):
    issues.append('معرّف الحزمة ما زال com.example. أعد flutter create بـ --org خاص بك قبل النشر.')
print('\n' + ('تنبيهات:\n - ' + '\n - '.join(issues) if issues else 'تم التجهيز بدون تنبيهات.'))
