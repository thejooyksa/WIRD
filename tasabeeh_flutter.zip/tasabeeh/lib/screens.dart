import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/services.dart';
import 'package:flutter_compass/flutter_compass.dart';
import 'package:hijri/hijri_calendar.dart';
import 'occasions.dart';
import 'dart:math' as math;
import 'package:wakelock_plus/wakelock_plus.dart';
import 'azkar.dart';
import 'package:geolocator/geolocator.dart';
import 'notifications.dart';
import 'prayer.dart';
import 'theme.dart';
import 'quran.dart';
import 'state.dart';

class HomeShell extends StatefulWidget {
  final AppState s;
  const HomeShell(this.s, {super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int i = 0;

  @override
  void initState() {
    super.initState();
    Notifier.payload.addListener(_onPayload);
    WidgetsBinding.instance.addPostFrameCallback((_) => _onPayload());
  }

  void _onPayload() {
    final p = Notifier.payload.value;
    if (p == 'wird') {
      Notifier.payload.value = null;
      if (mounted) setState(() => i = 0);
      return;
    }
    if (p == 'khatma') {
      Notifier.payload.value = null;
      widget.s.setQuranTab('k');
      if (mounted) setState(() => i = 3);
      return;
    }
    if (p == null || !p.startsWith('azkar')) return;
    Notifier.payload.value = null;
    widget.s.azAuto = false;
    widget.s.openAzkar(p == 'azkar_m');
    if (mounted) setState(() => i = 1);
  }

  @override
  void dispose() {
    Notifier.payload.removeListener(_onPayload);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 680), child: IndexedStack(index: i, children: [
            CounterScreen(widget.s),
            AzkarScreen(widget.s),
            PrayerScreen(widget.s),
            QuranScreen(widget.s),
            StatsScreen(widget.s),
            SettingsScreen(widget.s),
          ]))),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: i,
          onDestinationSelected: (v) {
            if (v == 1 && widget.s.azAuto) {
              widget.s.azAuto = false;
              final n = widget.s.nextPrayer().i;
              widget.s.setAzCat(n == 0 ? 's' : (n == 2 ? 'm' : 'e'));
            }
            setState(() => i = v);
          },
          destinations: const [
            NavigationDestination(icon: Icon(Icons.touch_app_outlined), selectedIcon: Icon(Icons.touch_app), label: 'العداد'),
            NavigationDestination(icon: Icon(Icons.wb_sunny_outlined), selectedIcon: Icon(Icons.wb_sunny), label: 'الأذكار'),
            NavigationDestination(icon: Icon(Icons.access_time_outlined), selectedIcon: Icon(Icons.access_time_filled), label: 'الصلاة'),
            NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'القرآن'),
            NavigationDestination(icon: Icon(Icons.bar_chart_outlined), selectedIcon: Icon(Icons.bar_chart), label: 'الإحصائيات'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
          ],
        ),
      );
}

// ───────────────────────── العداد ─────────────────────────
class BeadsPainter extends CustomPainter {
  final int n, lit;
  final Color gold, dim;
  BeadsPainter(this.n, this.lit, this.gold, this.dim);
  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    canvas.drawCircle(c, r - 2, Paint()..style = PaintingStyle.stroke..strokeWidth = 2.2..color = gold);
    canvas.drawCircle(c, r - 9, Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = dim);
    for (var i = 0; i < n; i++) {
      final a = -1.5707963 + 6.2831853 * i / n;
      final p = c + Offset.fromDirection(a, r * 0.78);
      canvas.drawCircle(p, i < lit ? 5.6 : 3.6, Paint()..color = i < lit ? gold : dim);
    }
  }

  @override
  bool shouldRepaint(BeadsPainter o) => true;
}

class CounterScreen extends StatelessWidget {
  final AppState s;
  const CounterScreen(this.s, {super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) {
          final cs = Theme.of(context).colorScheme;
          final t = s.target, c = s.sessionCount;
          final shown = (c > 0 && c % t == 0) ? t : c % t;
          final rounds = c ~/ t;
          final n = t < 48 ? t : 48;
          final lit = (n * shown / t).round();
          final goalP = (s.today / s.dailyGoal).clamp(0.0, 1.0);
          return Padding(
            padding: const EdgeInsets.fromLTRB(18, 8, 18, 12),
            child: Column(children: [
              Text('✦  تسابيح  ✦',
                  style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700, fontFamily: quranFont, color: cs.primary)),
              const SizedBox(height: 8),
              InkWell(
                onTap: () => _pick(context),
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  decoration: BoxDecoration(
                      color: cs.surface,
                      border: Border.all(color: cs.primary.withOpacity(.4)),
                      borderRadius: BorderRadius.circular(20)),
                  child: Row(children: [
                    Expanded(
                        child: Text(s.current.text,
                            style:  TextStyle(fontSize: 26, fontWeight: FontWeight.w700, fontFamily: quranFont))),
                    Icon(Icons.expand_more, color: cs.primary),
                  ]),
                ),
              ),
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: s.tap,
                  child: Center(
                    child: SizedBox(
                      width: 290,
                      height: 290,
                      child: Stack(alignment: Alignment.center, children: [
                        SizedBox.expand(
                            child: CustomPaint(painter: BeadsPainter(n, lit, cs.primary, cs.outlineVariant))),
                        Column(mainAxisSize: MainAxisSize.min, children: [
                          Text(ar(shown), semanticsLabel: 'العدد ${ar(shown)} من ${ar(t)}', style: TextStyle(fontSize: 84, fontWeight: FontWeight.w700, fontFamily: quranFont, color: cs.primary)),
                          TextButton(onPressed: () => _editTarget(context), child: Text('من ${ar(t)}  ✎')),
                          if (rounds > 0) Text('الدورات: ${ar(rounds)}'),
                        ]),
                      ]),
                    ),
                  ),
                ),
              ),
              Text('اضغط في أي مكان للتسبيح', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13)),
              const SizedBox(height: 8),
              Wrap(spacing: 8, alignment: WrapAlignment.center, children: [
                ActionChip(label: const Text('تراجع'), onPressed: s.undo),
                ActionChip(label: const Text('تصفير'), onPressed: s.resetCurrent),
                FilterChip(
                    label: const Text('تسبيح ما بعد الصلاة'),
                    selected: s.seq,
                    onSelected: (_) => s.toggleSeq()),
              ]),
              const SizedBox(height: 12),
              Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Text('هدف اليوم: ${ar(s.today)} / ${ar(s.dailyGoal)}')),
              const SizedBox(height: 6),
              LinearProgressIndicator(value: goalP, minHeight: 8, color: cs.primary, borderRadius: BorderRadius.circular(8)),
            ]),
          );
        },
      );

  void _pick(BuildContext context) => showModalBottomSheet(
        context: context,
        showDragHandle: true,
        isScrollControlled: true,
        builder: (_) => ListenableBuilder(
          listenable: s,
          builder: (ctx, _) => ListView(shrinkWrap: true, children: [
            for (final d in s.all)
              ListTile(
                title: Text(d.text, style:  TextStyle(fontFamily: quranFont, fontSize: 20)),
                subtitle: Text('المجموع: ${ar(s.lifetime[d.id] ?? 0)}'),
                trailing: d.id == s.currentId ? const Icon(Icons.check_circle) : null,
                onTap: () {
                  s.select(d.id);
                  Navigator.pop(ctx);
                },
              ),
            const SizedBox(height: 12),
          ]),
        ),
      );

  void _editTarget(BuildContext context) {
    final ctrl = TextEditingController(text: '${s.target}');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('عدد التسبيحات في الدورة'),
        content: TextField(
            controller: ctrl,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
              onPressed: () {
                s.setTarget(int.tryParse(ctrl.text) ?? s.target);
                Navigator.pop(ctx);
              },
              child: const Text('حفظ')),
        ],
      ),
    );
  }
}

// ───────────────────────── الإحصائيات ─────────────────────────
class StatsScreen extends StatelessWidget {
  final AppState s;
  const StatsScreen(this.s, {super.key});

  static const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) {
          final cs = Theme.of(context).colorScheme;
          final week = s.last7;
          final maxV = week.map((e) => e.$2).fold(1, (a, b) => a > b ? a : b);
          final top = s.lifetime.entries.where((e) => e.value > 0).toList()
            ..sort((a, b) => b.value.compareTo(a.value));
          String name(String id) =>
              s.all.where((d) => d.id == id).map((d) => d.text).firstOrNull ?? id;
          return ListView(padding: const EdgeInsets.all(16), children: [
            Row(children: [
              _stat(context, 'اليوم', ar(s.today), Icons.today),
              _stat(context, 'السلسلة', '${ar(s.streak)} يوم', Icons.local_fire_department),
              _stat(context, 'المجموع', ar(s.total), Icons.all_inclusive),
            ]),
            const SizedBox(height: 16),
            Text('تسبيحات اليوم', style: Theme.of(context).textTheme.titleMedium),
            if (s.todayLog().isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text('لم تسبّح اليوم بعد')),
            for (final e in s.todayLog()) ListTile(dense: true, title: Text(name(e.key)), trailing: Text(ar(e.value))),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: FilledButton.icon(
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: s.shareText()));
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ النص، الصقه حيث تشاء')));
                  }
                },
                icon: const Icon(Icons.share),
                label: const Text('مشاركة إنجازي'),
              ),
            ),
            const SizedBox(height: 20),
            Text('آخر ٧ أيام', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 12),
            SizedBox(
              height: 170,
              child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                for (final e in week)
                  Expanded(
                    child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                      Text(ar(e.$2), style: const TextStyle(fontSize: 11)),
                      const SizedBox(height: 4),
                      Container(
                        height: 4 + 110 * (e.$2 / maxV),
                        margin: const EdgeInsets.symmetric(horizontal: 5),
                        decoration: BoxDecoration(
                            color: e.$2 >= s.dailyGoal ? cs.primary : cs.primary.withOpacity(.45),
                            borderRadius: BorderRadius.circular(6)),
                      ),
                      const SizedBox(height: 4),
                      FittedBox(
                          child: Text(days[e.$1.weekday % 7],
                              style: const TextStyle(fontSize: 11))),
                    ]),
                  ),
              ]),
            ),
            const SizedBox(height: 20),
            ...monthStats(context, s),
            Text('الأكثر ذكرًا', style: Theme.of(context).textTheme.titleMedium),
            if (top.isEmpty)
              const Padding(padding: EdgeInsets.all(12), child: Text('ابدأ التسبيح لتظهر إحصائياتك')),
            for (final e in top.take(5))
              ListTile(
                  dense: true,
                  title: Text(name(e.key)),
                  trailing: Text(ar(e.value))),
            const SizedBox(height: 12),
            Text('الإنجازات', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 2.3,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              children: [
                for (final a in s.achievements)
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                        color: a.ok ? cs.primaryContainer : cs.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(14)),
                    child: Row(children: [
                      Icon(a.ok ? Icons.emoji_events : Icons.lock_outline,
                          color: a.ok ? const Color(0xFFC8A96B) : cs.outline),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(a.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                              Text(a.desc, style: const TextStyle(fontSize: 11)),
                            ]),
                      ),
                    ]),
                  ),
              ],
            ),
          ]);
        },
      );

  Widget _stat(BuildContext context, String label, String value, IconData icon) {
    final cs = Theme.of(context).colorScheme;
    return Expanded(
      child: Card(
        color: cs.secondaryContainer,
        elevation: 0,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Column(children: [
            Icon(icon, color: cs.onSecondaryContainer),
            const SizedBox(height: 4),
            FittedBox(
                child: Text(value,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
            Text(label, style: const TextStyle(fontSize: 12)),
          ]),
        ),
      ),
    );
  }
}

// ───────────────────────── الإعدادات ─────────────────────────
class SettingsScreen extends StatelessWidget {
  final AppState s;
  const SettingsScreen(this.s, {super.key});

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) => ListView(children: [
          ...themeSettings(context, s),
          ListTile(
            title: const Text('الأرقام'),
            trailing: SegmentedButton<String>(
              segments: const [ButtonSegment(value: 'ar', label: Text('١٢٣')), ButtonSegment(value: 'en', label: Text('123'))],
              selected: {s.digits},
              onSelectionChanged: (v) => s.setDigits(v.first),
            ),
          ),
          SwitchListTile(
              title: const Text('تذكير بورد الذكر اليومي'),
              subtitle: const Text('يذكّرك بالتسبيح وهدفك اليومي في الأوقات التي تحددها'),
              value: s.wRem,
              onChanged: (v) {
                if (v) Notifier.requestPermission();
                s.setWRem(v);
              }),
          if (s.wRem) ...[
            for (var k = 0; k < s.wTimes.length; k++)
              ListTile(
                dense: true,
                leading: const Icon(Icons.alarm),
                title: Text(fmtT(s.wTimes[k] / 60, s.p24)),
                trailing: IconButton(
                    icon: const Icon(Icons.delete_outline), onPressed: s.wTimes.length > 1 ? () => s.removeWTime(k) : null),
              ),
            if (s.wTimes.length < 4)
              TextButton.icon(
                icon: const Icon(Icons.add_alarm),
                label: const Text('إضافة وقت'),
                onPressed: () async {
                  final t = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 12, minute: 0));
                  if (t != null) s.addWTime(t.hour * 60 + t.minute);
                },
              ),
          ],
          SwitchListTile(
              title: const Text('إشعار العدّ السريع'),
              subtitle: const Text('زر +١ في الإشعار يعدّ حتى من الشاشة المقفلة'),
              value: s.quickNotif,
              onChanged: (v) {
                if (v) Notifier.requestPermission();
                s.setQuickNotif(v);
              }),
          SwitchListTile(
              title: const Text('الاهتزاز'),
              subtitle: const Text('اهتزاز خفيف مع كل تسبيحة وقوي عند إكمال الدورة'),
              value: s.haptics,
              onChanged: (v) => s.set(haptics: v)),
          SwitchListTile(
              title: const Text('صوت النقر'),
              subtitle: const Text('أوقفه للوضع الصامت'),
              value: s.sound,
              onChanged: (v) => s.set(sound: v)),
          ListTile(
            title: const Text('الهدف اليومي'),
            subtitle: Text('${ar(s.dailyGoal)} تسبيحة'),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(
                  onPressed: () => s.set(goal: (s.dailyGoal - 50).clamp(50, 100000)),
                  icon: const Icon(Icons.remove_circle_outline)),
              IconButton(
                  onPressed: () => s.set(goal: s.dailyGoal + 50),
                  icon: const Icon(Icons.add_circle_outline)),
            ]),
          ),
          const Divider(),
          SwitchListTile(
              title: const Text('تذكير يومي'),
              subtitle: Text('الساعة ${_fmt(s.remHour, s.remMin)}'),
              value: s.reminder,
              onChanged: (v) => s.setReminder(v)),
          ListTile(
            enabled: s.reminder,
            title: const Text('وقت التذكير'),
            trailing: const Icon(Icons.access_time),
            onTap: () async {
              final t = await showTimePicker(
                  context: context,
                  initialTime: TimeOfDay(hour: s.remHour, minute: s.remMin));
              if (t != null) s.setReminder(true, h: t.hour, m: t.minute);
            },
          ),
          const Divider(),
          azReminderTile(context, s, true),
          azReminderTile(context, s, false),
          const Divider(),
          ListTile(
              leading: const Icon(Icons.add),
              title: const Text('إضافة ذكر مخصص'),
              onTap: () => _addDialog(context)),
          for (final d in s.customAzkar)
            ListTile(
                title: Text(d.text),
                trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => s.removeCustom(d.id))),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.backup_outlined),
            title: const Text('نسخ احتياطي'),
            subtitle: const Text('ينسخ بياناتك كنص إلى الحافظة'),
            onTap: () async {
              await Clipboard.setData(ClipboardData(text: s.exportJson()));
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم نسخ النسخة الاحتياطية. الصقها في ملاحظاتك أو أرسلها لنفسك.')));
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.restore),
            title: const Text('استعادة من نسخة احتياطية'),
            onTap: () => restoreDialog(context, s),
          ),
          ListTile(
            leading: const Icon(Icons.battery_alert_outlined),
            title: const Text('لا تصلني الإشعارات في وقتها؟'),
            onTap: () => batteryHelp(context),
          ),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('حول التطبيق'),
            onTap: () => showAboutDialog(
              context: context,
              applicationName: 'تسابيح',
              applicationVersion: '1.0.0',
              children: const [
                Text('نص القرآن الكريم من مشروع Tanzil.net (الرسم العثماني) بترخيص CC BY 3.0، ولم يُعدَّل.\n\n'
                    'الأذكار من كتاب حصن المسلم.\n\n'
                    'الخطوط (Amiri وScheherazade New وNoto وLateef وCairo وTajawal) بترخيص SIL OFL من مشروع Google Fonts.\n\n'
                    'التطبيق يعمل دون إنترنت ولا يجمع أي بيانات عنك. أوقات الصلاة تُحسب على جهازك.'),
              ],
            ),
          ),
          ListTile(
            leading: const Icon(Icons.delete_forever, color: Colors.red),
            title: const Text('مسح كل الإحصائيات'),
            onTap: () => showDialog(
              context: context,
              builder: (ctx) => AlertDialog(
                title: const Text('تأكيد المسح'),
                content: const Text('سيتم حذف العدادات والإحصائيات والسلسلة. لا يمكن التراجع.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
                  FilledButton(
                      onPressed: () {
                        s.resetAll();
                        Navigator.pop(ctx);
                      },
                      child: const Text('مسح')),
                ],
              ),
            ),
          ),
        ]),
      );

  String _fmt(int h, int m) {
    final p = h >= 12 ? 'م' : 'ص';
    final hh = h % 12 == 0 ? 12 : h % 12;
    return '${ar(hh)}:${ar(m.toString().padLeft(2, '0'))} $p';
  }

  void _addDialog(BuildContext context) {
    final text = TextEditingController(), target = TextEditingController(text: '33');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ذكر جديد'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: text, decoration: const InputDecoration(labelText: 'نص الذكر')),
          TextField(
              controller: target,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(labelText: 'العدد في الدورة')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
              onPressed: () {
                if (text.text.trim().isNotEmpty) {
                  s.addCustom(text.text.trim(), int.tryParse(target.text) ?? 33);
                }
                Navigator.pop(ctx);
              },
              child: const Text('إضافة')),
        ],
      ),
    );
  }
}

// ───────────────────────── القرآن ─────────────────────────
Widget numCircle(BuildContext context, int n) {
  final cs = Theme.of(context).colorScheme;
  return Container(
    width: 38,
    height: 38,
    alignment: Alignment.center,
    decoration: BoxDecoration(border: Border.all(color: cs.primary), shape: BoxShape.circle),
    child: Text(ar(n), style: TextStyle(fontSize: 13, color: cs.primary)),
  );
}

class QuranScreen extends StatefulWidget {
  final AppState s;
  const QuranScreen(this.s, {super.key});
  @override
  State<QuranScreen> createState() => _QuranState();
}

class _QuranState extends State<QuranScreen> {
  String get tab => widget.s.quranTab; // s سور، j أجزاء، m علامات، k ختمة
  final ctrl = TextEditingController();
  String term = '';
  AppState get s => widget.s;

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  void _open(int n, {double y = 0, int? verse}) {
    if (!Quran.data.containsKey(n)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('السورة غير مضافة. ضع ملف المصحف في assets/quran (انظر README).')));
      return;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => ReaderScreen(s, n, y, verse: verse)));
  }

  List<Widget> _results(ColorScheme cs) {
    if (Quran.normMap(term.trim()).$1.length < 2) return [const Padding(padding: EdgeInsets.all(12), child: Text('اكتب حرفين على الأقل'))];
    final r = Quran.search(term);
    if (r.isEmpty) return [const Padding(padding: EdgeInsets.all(12), child: Text('لا توجد نتائج'))];
    return [
      Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Text('${ar(r.length)} نتيجة${r.length > 50 ? ' (تُعرض أول ٥٠)' : ''}', style: TextStyle(color: cs.onSurfaceVariant))),
      for (final x in r.take(50))
        Builder(builder: (context) {
          final sn = Quran.snippet(x.$1, x.$2, x.$3, x.$4);
          return ListTile(
            leading: numCircle(context, x.$2),
            title: Text.rich(
              TextSpan(children: [
                TextSpan(text: sn.$1),
                TextSpan(text: sn.$2, style: TextStyle(backgroundColor: cs.primary.withOpacity(.3))),
                TextSpan(text: sn.$3),
              ]),
              style:  TextStyle(fontFamily: quranFont, fontSize: 19, height: 1.8),
            ),
            trailing: Text(surahNames[x.$1 - 1], style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
            onTap: () => _open(x.$1, verse: x.$2),
          );
        }),
    ];
  }

  List<Widget> _khatma(ColorScheme cs) {
    if (Quran.data.length < 114) {
      return [const Padding(padding: EdgeInsets.all(16), child: Text('تحتاج الختمة المصحف كاملًا (١١٤ سورة).'))];
    }
    final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: cs.primary.withOpacity(.4)));
    if (!s.khOn) {
      return [
        Card(
          color: cs.surface,
          shape: shape,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              const Text('ختمة القرآن', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
              const SizedBox(height: 4),
              Text('اختر مدة الختمة فيحسب التطبيق ورد كل يوم ويتابع تقدمك.', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
              const SizedBox(height: 10),
              Wrap(spacing: 8, children: [
                for (final d in const [15, 20, 30, 60, 90]) ChoiceChip(label: Text('${ar(d)} يومًا'), selected: s.khDays == d, onSelected: (_) => s.khSetDays(d)),
              ]),
              const SizedBox(height: 10),
              FilledButton(onPressed: s.khStartPlan, child: const Text('ابدأ الختمة')),
            ]),
          ),
        ),
        if (s.khCount > 0) Padding(padding: const EdgeInsets.all(8), child: Text('ختمات مكتملة: ${ar(s.khCount)}', textAlign: TextAlign.center)),
      ];
    }
    final dn = s.khDays, nx = s.khNext;
    final idx = math.min(dn, s.khDaysSince() + 1), behind = math.max(0, idx - s.khDone.length);
    final bar = <Widget>[
      const SizedBox(height: 8),
      LinearProgressIndicator(value: s.khDone.length / dn, minHeight: 8, color: cs.primary, borderRadius: BorderRadius.circular(8)),
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Text('أنجزت ${ar(s.khDone.length)} من ${ar(dn)} يومًا، ${behind > 0 ? 'متأخر ${ar(behind)} يومًا' : 'أنت في الموعد'}', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant)),
      ),
    ];
    if (nx == 0) {
      return [
        Card(color: cs.surface, shape: shape, child: const ListTile(title: Text('ما شاء الله، أتممت الختمة', textAlign: TextAlign.center), subtitle: Text('تقبّل الله منك', textAlign: TextAlign.center))),
        ...bar,
        FilledButton(onPressed: s.khFinish, child: const Text('ختمة جديدة')),
      ];
    }
    final r = Quran.khRange(nx, dn);
    final h = s.khRemH % 12 == 0 ? 12 : s.khRemH % 12;
    return [
      Card(
        color: cs.surface,
        shape: shape,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Text('ورد اليوم رقم ${ar(nx)} من ${ar(dn)}', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
            Text('من سورة ${surahNames[r.$1.$1 - 1]} آية ${ar(r.$1.$2)}\nإلى سورة ${surahNames[r.$2.$1 - 1]} آية ${ar(r.$2.$2)}',
                textAlign: TextAlign.center, style:  TextStyle(fontSize: 22, height: 2, fontFamily: quranFont)),
            const SizedBox(height: 8),
            Wrap(spacing: 8, children: [
              OutlinedButton(onPressed: () => _open(r.$1.$1, verse: r.$1.$2), child: const Text('افتح الورد')),
              FilledButton(onPressed: () => s.khMarkDone(nx), child: const Text('تم قراءته')),
            ]),
          ]),
        ),
      ),
      ...bar,
      SwitchListTile(
        title: const Text('تذكير يومي بالورد'),
        subtitle: Text('الساعة ${ar(h)}:${ar(s.khRemM.toString().padLeft(2, '0'))} ${s.khRemH >= 12 ? 'م' : 'ص'} (اضغط الوقت أدناه لتغييره)'),
        value: s.khRem,
        onChanged: (v) {
          if (v) Notifier.requestPermission();
          s.setKhRem(v);
        },
      ),
      ListTile(
        enabled: s.khRem,
        title: const Text('وقت التذكير'),
        trailing: const Icon(Icons.access_time),
        onTap: () async {
          final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: s.khRemH, minute: s.khRemM));
          if (t != null) s.setKhRem(true, h: t.hour, m: t.minute);
        },
      ),
      TextButton(onPressed: s.khCancel, child: const Text('إلغاء الخطة')),
    ];
  }

  List<Widget> _tabs(ColorScheme cs) {
    final chips = Wrap(spacing: 8, children: [
      for (final c in const [('s', 'السور'), ('j', 'الأجزاء'), ('m', 'العلامات'), ('k', 'الختمة')])
        ChoiceChip(label: Text(c.$2), selected: tab == c.$1, onSelected: (_) => s.setQuranTab(c.$1)),
    ]);
    if (tab == 'j') {
      return [
        chips,
        for (var i = 0; i < juzStarts.length; i++)
          ListTile(
            leading: numCircle(context, i + 1),
            title: Text('الجزء ${ar(i + 1)}', style:  TextStyle(fontFamily: quranFont, fontSize: 22, fontWeight: FontWeight.w700)),
            trailing: Text('${surahNames[juzStarts[i][0] - 1]} ${ar(juzStarts[i][1])}', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
            onTap: () => _open(juzStarts[i][0], verse: juzStarts[i][1]),
          ),
      ];
    }
    if (tab == 'k') return [chips, const SizedBox(height: 8), ..._khatma(cs)];
    if (tab == 'm') {
      return [
        chips,
        if (s.marks.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('لا توجد علامات. اضغط على أي آية أثناء القراءة لإضافة علامة.')),
        for (var i = 0; i < s.marks.length; i++)
          ListTile(
            leading: Icon(Icons.bookmark, color: cs.primary),
            title: Text('سورة ${surahNames[s.marks[i][0] - 1]}', style:  TextStyle(fontFamily: quranFont, fontSize: 22, fontWeight: FontWeight.w700)),
            subtitle: Text('آية ${ar(s.marks[i][1])}'),
            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => s.removeMarkAt(i)),
            onTap: () => _open(s.marks[i][0], verse: s.marks[i][1]),
          ),
      ];
    }
    final keys = Quran.data.keys.toList()..sort();
    final verses = [
      for (final k in keys)
        for (var i = 0; i < Quran.data[k]!.length; i++)
          if (Quran.data[k]![i].isNotEmpty && Quran.data[k]![i].length < 140) (k, i + 1, Quran.data[k]![i])
    ];
    final now = DateTime.now();
    final v = verses.isEmpty ? null : verses[now.difference(DateTime(now.year)).inDays % verses.length];
    return [
      chips,
      const SizedBox(height: 8),
      if (v != null)
        Card(
          color: cs.surface,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: cs.primary.withOpacity(.4))),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(children: [
              Text('آية اليوم', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
              Text('${v.$3} ﴿${ar(v.$2)}﴾', textAlign: TextAlign.center, style:  TextStyle(fontSize: 24, height: 2, fontFamily: quranFont)),
              Text('سورة ${surahNames[v.$1 - 1]}', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
            ]),
          ),
        ),
      if (s.bmSurah > 0 && Quran.data.containsKey(s.bmSurah))
        Card(
          child: ListTile(
            leading: Icon(Icons.bookmark, color: cs.primary),
            title: Text('متابعة القراءة: سورة ${surahNames[s.bmSurah - 1]}'),
            onTap: () => _open(s.bmSurah, y: s.bmY),
          ),
        ),
      if (!Quran.full)
        Card(
          color: cs.surface,
          child: const Padding(
            padding: EdgeInsets.all(14),
            child: Text('المتاح الآن عدة سور قصيرة للتجربة. لإضافة المصحف الكامل ضع ملف Tanzil في assets/quran/quran-uthmani.txt (التفاصيل في README).', style: TextStyle(fontSize: 13)),
          ),
        ),
      for (var n = 1; n <= 114; n++)
        ListTile(
          leading: numCircle(context, n),
          title: Text(surahNames[n - 1],
              style: TextStyle(fontFamily: quranFont, fontSize: 22, fontWeight: FontWeight.w700, color: Quran.data.containsKey(n) ? null : cs.outline)),
          trailing: Text(Quran.data.containsKey(n) ? '${ar(Quran.data[n]!.length)} آية' : 'غير مضافة', style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
          onTap: () => _open(n),
        ),
    ];
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (context, _) {
          final cs = Theme.of(context).colorScheme;
          return ListView(padding: const EdgeInsets.all(16), children: [
            Text('القرآن الكريم', style: TextStyle(fontSize: 28, fontFamily: quranFont, fontWeight: FontWeight.w700, color: cs.primary)),
            const SizedBox(height: 8),
            TextField(
              controller: ctrl,
              onChanged: (v) => setState(() => term = v),
              decoration: InputDecoration(
                hintText: 'ابحث في القرآن: كلمة أو جزء من آية',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: term.isEmpty
                    ? null
                    : IconButton(
                        icon: const Icon(Icons.close),
                        onPressed: () {
                          ctrl.clear();
                          setState(() => term = '');
                        }),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
            const SizedBox(height: 10),
            ...(term.trim().isEmpty ? _tabs(cs) : _results(cs)),
          ]);
        },
      );
}

class ReaderScreen extends StatefulWidget {
  final AppState s;
  final int n;
  final double y;
  final int? verse;
  const ReaderScreen(this.s, this.n, this.y, {this.verse, super.key});
  @override
  State<ReaderScreen> createState() => _ReaderState();
}

class _ReaderState extends State<ReaderScreen> with SingleTickerProviderStateMixin {
  late final ScrollController sc = ScrollController(initialScrollOffset: widget.y);
  late final Ticker tick = createTicker(_onTick);
  late final List<String> verses = Quran.data[widget.n]!;
  late final List<TapGestureRecognizer> _recs = [
    for (var i = 0; i < verses.length; i++) TapGestureRecognizer()..onTap = () => _menu(i + 1)
  ];
  bool play = false;
  double pos = 0;
  Duration last = Duration.zero;
  Timer? bt;
  int _hl = 0;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    sc.addListener(() {
      bt?.cancel();
      bt = Timer(const Duration(milliseconds: 500), () {
        if (sc.hasClients) widget.s.setBookmark(widget.n, sc.offset);
      });
    });
    final v = widget.verse;
    if (v != null) WidgetsBinding.instance.addPostFrameCallback((_) => _jumpToVerse(v));
  }

  /// يحسب موضع الآية بقياس النص بنفس الخط والعرض ثم ينتقل إليها
  void _jumpToVerse(int v) {
    if (!mounted || !sc.hasClients) return;
    final fs = widget.s.fs;
    final marker = TextStyle(fontSize: fs * .7);
    final kids = <InlineSpan>[];
    var off = 0, target = 0;
    for (var i = 0; i < verses.length; i++) {
      if (verses[i].isEmpty) continue;
      if (i + 1 == v) target = off;
      final a = '${verses[i]} ', b = '﴿${ar(i + 1)}﴾ ';
      kids.add(TextSpan(text: a));
      kids.add(TextSpan(text: b, style: marker));
      off += a.length + b.length;
    }
    final tp = TextPainter(
      text: TextSpan(style: TextStyle(fontSize: fs, height: 2.2, fontFamily: quranFont), children: kids),
      textDirection: TextDirection.rtl,
      textAlign: TextAlign.justify,
    )..layout(maxWidth: MediaQuery.of(context).size.width - 40);
    final y = tp.getOffsetForCaret(TextPosition(offset: target), Rect.zero).dy;
    final header = (widget.n != 1 && widget.n != 9) ? fs * 1.5 + 24 : 0;
    sc.jumpTo((y + 12 + header - 80).clamp(0.0, sc.position.maxScrollExtent).toDouble());
    setState(() => _hl = v);
    Timer(const Duration(seconds: 2), () {
      if (mounted) setState(() => _hl = 0);
    });
  }

  void _menu(int a) {
    final s = widget.s, n = widget.n, t = verses[a - 1];
    if (play) _set(false);
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) => ListenableBuilder(
        listenable: s,
        builder: (ctx, _) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('سورة ${surahNames[n - 1]}، آية ${ar(a)}', style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text(t, textAlign: TextAlign.center, style:  TextStyle(fontSize: 22, height: 2, fontFamily: quranFont)),
              const SizedBox(height: 12),
              Wrap(spacing: 8, children: [
                FilledButton.icon(
                  onPressed: () => s.toggleMark(n, a),
                  icon: Icon(s.hasMark(n, a) ? Icons.bookmark_remove : Icons.bookmark_add),
                  label: Text(s.hasMark(n, a) ? 'إزالة العلامة' : 'إضافة علامة'),
                ),
                OutlinedButton.icon(
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: '$t ﴿${ar(a)}﴾ [${surahNames[n - 1]}]'));
                    if (ctx.mounted) {
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم النسخ')));
                    }
                  },
                  icon: const Icon(Icons.copy),
                  label: const Text('نسخ'),
                ),
              ]),
            ]),
          ),
        ),
      ),
    );
  }

  void _onTick(Duration d) {
    final dt = (d - last).inMicroseconds / 1e6;
    last = d;
    if (!sc.hasClients) return;
    final max = sc.position.maxScrollExtent;
    pos += (8 + widget.s.speed * 14) * dt;
    if (pos >= max) {
      sc.jumpTo(max);
      _set(false);
      return;
    }
    sc.jumpTo(pos);
  }

  void _set(bool p) {
    if (p == play) return;
    setState(() => play = p);
    if (p) {
      pos = sc.hasClients ? sc.offset : 0;
      last = Duration.zero;
      tick.start();
    } else {
      tick.stop();
    }
  }

  @override
  void dispose() {
    bt?.cancel();
    if (sc.hasClients) widget.s.setBookmark(widget.n, sc.offset, notify: false);
    for (final r in _recs) {
      r.dispose();
    }
    tick.stop();
    tick.dispose();
    sc.dispose();
    WakelockPlus.disable();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text('سورة ${surahNames[widget.n - 1]}', style:  TextStyle(fontFamily: quranFont, fontSize: 24))),
      body: Column(children: [
        Expanded(
          child: Listener(
            onPointerDown: (_) {
              if (play) _set(false);
            },
            child: ListenableBuilder(
              listenable: s,
              builder: (_, __) => SingleChildScrollView(
                controller: sc,
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 60),
                child: Column(children: [
                  if (widget.n != 1 && widget.n != 9)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      child: Text('بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ', style: TextStyle(fontSize: s.fs, color: cs.primary, fontFamily: quranFont)),
                    ),
                  Text.rich(
                    TextSpan(
                      style: TextStyle(fontSize: s.fs, height: 2.2, fontFamily: quranFont),
                      children: [
                        for (var i = 0; i < verses.length; i++)
                          if (verses[i].isNotEmpty) ...[
                            TextSpan(
                                text: '${verses[i]} ',
                                recognizer: _recs[i],
                                style: i + 1 == _hl ? TextStyle(backgroundColor: cs.primary.withOpacity(.25)) : null),
                            TextSpan(
                                text: '﴿${ar(i + 1)}﴾ ',
                                recognizer: _recs[i],
                                style: TextStyle(color: s.hasMark(widget.n, i + 1) ? cs.error : cs.primary, fontSize: s.fs * .7)),
                          ],
                      ],
                    ),
                    textAlign: TextAlign.justify,
                  ),
                ]),
              ),
            ),
          ),
        ),
        Material(
          color: cs.surface,
          elevation: 8,
          child: SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
              child: ListenableBuilder(
                listenable: s,
                builder: (_, __) => Row(children: [
                  FilledButton.icon(onPressed: () => _set(!play), icon: Icon(play ? Icons.pause : Icons.play_arrow), label: Text(play ? 'إيقاف' : 'تشغيل')),
                  Expanded(child: Slider(value: s.speed, min: 1, max: 10, divisions: 9, label: ar(s.speed.round()), onChanged: (x) => s.setReader(speed: x))),
                  IconButton(onPressed: () => s.setReader(fs: (s.fs - 3).clamp(20.0, 60.0).toDouble()), icon: const Text('أ−')),
                  IconButton(onPressed: () => s.setReader(fs: (s.fs + 3).clamp(20.0, 60.0).toDouble()), icon: const Text('أ+')),
                ]),
              ),
            ),
          ),
        ),
      ]),
    );
  }
}

// ───────────────────────── الأذكار ─────────────────────────
class AzkarScreen extends StatefulWidget {
  final AppState s;
  const AzkarScreen(this.s, {super.key});
  @override
  State<AzkarScreen> createState() => _AzkarState();
}

class _AzkarState extends State<AzkarScreen> {
  static const cats = [('m', 'الصباح'), ('e', 'المساء'), ('s', 'النوم'), ('p', 'بعد الصلاة'), ('w', 'الاستيقاظ'), ('d', 'متنوعة'), ('u', 'قائمتي')];
  String get cat => widget.s.azCat;

  List<Zikr> _list() => cat == 'm'
      ? [for (final z in azkar) if (z.q != null || z.m != null) z]
      : cat == 'e'
          ? azkar
          : cat == 'u'
              ? [for (final u in widget.s.uz) Zikr(u['id'] as String, null, u['m'] as String, null, u['n'] as int, null, 'u')]
              : [for (final z in azkarMore) if (z.cat == cat) z];

  String _text(Zikr z) {
    final q = z.q;
    if (q != null) {
      final l = Quran.data[q[0]] ?? [];
      if (q.length == 3) {
        return [for (var i = q[1]; i <= q[2] && i <= l.length; i++) '${l[i - 1]} ﴿${ar(i)}﴾'].join(' ');
      }
      if (q.length == 2) return q[1] <= l.length ? l[q[1] - 1] : '';
      return [for (var i = 0; i < l.length; i++) if (l[i].isNotEmpty) '${l[i]} ﴿${ar(i + 1)}﴾'].join(' ');
    }
    return (cat == 'e' ? (z.e ?? z.m) : z.m) ?? '';
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: widget.s,
        builder: (context, _) {
          final s = widget.s;
          final cs = Theme.of(context).colorScheme;
          final today = dayKey(DateTime.now());
          final list = _list();
          int got(Zikr z) => s.az['$today|$cat|${z.id}'] ?? 0;
          final done = list.where((z) => got(z) >= z.n).length;
          return ListView(padding: const EdgeInsets.all(16), children: [
            Text('الأذكار',
                style: TextStyle(fontSize: 28, fontFamily: quranFont, fontWeight: FontWeight.w700, color: cs.primary)),
            const SizedBox(height: 12),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                for (final c in cats)
                  Padding(
                    padding: const EdgeInsetsDirectional.only(end: 8),
                    child: ChoiceChip(label: Text(c.$2), selected: cat == c.$1, onSelected: (_) => s.setAzCat(c.$1)),
                  ),
              ]),
            ),
            const SizedBox(height: 10),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text('${ar(done)} من ${ar(list.length)}'),
              TextButton(onPressed: () => s.azReset('$today|$cat|'), child: const Text('إعادة البدء')),
            ]),
            LinearProgressIndicator(value: list.isEmpty ? 0 : done / list.length, minHeight: 8, color: cs.primary, borderRadius: BorderRadius.circular(8)),
            if (cat == 'u')
              FilledButton.icon(onPressed: () => addUzDialog(context, s), icon: const Icon(Icons.add), label: const Text('إضافة ذكر إلى قائمتي')),
            const SizedBox(height: 6),
            Text(cat == 'u' && list.isEmpty ? 'قائمتك فارغة. أضف أذكارًا أو أدعية تقرؤها كل يوم.' : 'اضغط على الذكر بعد قراءته ليُحتسب', textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
            const SizedBox(height: 10),
            for (final z in list)
              Builder(builder: (_) {
                final left = (z.n - got(z)).clamp(0, z.n);
                return Opacity(
                  opacity: left == 0 ? .5 : 1,
                  child: Card(
                    color: cs.surface,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20), side: BorderSide(color: cs.primary.withOpacity(.35))),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(20),
                      onTap: () => s.azTap('$today|$cat|${z.id}', z.n),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(children: [
                          if (z.label != null) Text(z.label!, style: TextStyle(color: cs.primary, fontWeight: FontWeight.w800)),
                          Text(_text(z), textAlign: TextAlign.center, style:  TextStyle(fontSize: 22, height: 2, fontFamily: quranFont)),
                          Text(left == 0 ? '✓ تم' : 'المتبقي ${ar(left)} من ${ar(z.n)}',
                              style: TextStyle(fontSize: 13, color: left == 0 ? cs.primary : cs.onSurfaceVariant)),
                          if (cat == 'u') TextButton(onPressed: () => s.removeUz(z.id), child: const Text('حذف')),
                        ]),
                      ),
                    ),
                  ),
                );
              }),
            Text('الأذكار من كتاب حصن المسلم، وآيات القرآن من نص Tanzil.',
                textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
          ]);
        },
      );
}

// ───────────────────────── أوقات الصلاة ─────────────────────────
String fmtT(double h, bool h24) {
  if (h.isNaN) return '--:--';
  var t = h + .5 / 60;
  t = t - 24 * (t / 24).floorToDouble();
  var hh = t.floor();
  final mm = ((t - hh) * 60).floor();
  var suf = '';
  if (!h24) {
    suf = hh >= 12 ? ' م' : ' ص';
    hh = hh % 12 == 0 ? 12 : hh % 12;
  }
  return '${ar(hh.toString().padLeft(h24 ? 2 : 1, '0'))}:${ar(mm.toString().padLeft(2, '0'))}$suf';
}

class NextPrayerCard extends StatefulWidget {
  final AppState s;
  const NextPrayerCard(this.s, {super.key});
  @override
  State<NextPrayerCard> createState() => _NextCardState();
}

class _NextCardState extends State<NextPrayerCard> {
  Timer? _t;
  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final n = widget.s.nextPrayer();
    final sec = n.left.inSeconds;
    final cd = [sec ~/ 3600, sec % 3600 ~/ 60, sec % 60].map((x) => x.toString().padLeft(2, '0')).join(':');
    return Card(
      color: cs.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: cs.primary.withOpacity(.4))),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(children: [
          Text('الصلاة القادمة في ${widget.s.pName}', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
          Text(prayerNames[n.i], style: TextStyle(fontSize: 40, fontFamily: quranFont, fontWeight: FontWeight.w700, color: cs.primary)),
          Text(ar(cd), style: TextStyle(fontSize: 28, fontFamily: quranFont, fontWeight: FontWeight.w700, color: cs.primary)),
        ]),
      ),
    );
  }
}

class PrayerScreen extends StatefulWidget {
  final AppState s;
  const PrayerScreen(this.s, {super.key});
  @override
  State<PrayerScreen> createState() => _PrayerState();
}

class _PrayerState extends State<PrayerScreen> {
  int _prOff = 0;
  Timer? _t;
  int _last = -1;
  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      final i = widget.s.nextPrayer().i;
      if (i != _last && mounted) {
        _last = i;
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  void _msg(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _gps() async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) return _msg('فعّل خدمة الموقع في جهازك');
      var p = await Geolocator.checkPermission();
      if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
      if (p == LocationPermission.denied || p == LocationPermission.deniedForever) {
        return _msg('لم يُمنح إذن الموقع. اختر مدينتك أو أدخل الإحداثيات');
      }
      final pos = await Geolocator.getCurrentPosition(
          locationSettings: const LocationSettings(accuracy: LocationAccuracy.low));
      widget.s.updatePrayer(() {
        widget.s.pCity = -1;
        widget.s.pLat = double.parse(pos.latitude.toStringAsFixed(4));
        widget.s.pLng = double.parse(pos.longitude.toStringAsFixed(4));
        widget.s.pTz = 'local';
        widget.s.pName = 'موقعي الحالي';
      });
    } catch (_) {
      _msg('تعذر تحديد الموقع');
    }
  }

  void _manual() {
    final la = TextEditingController(text: '${widget.s.pLat}'), lo = TextEditingController(text: '${widget.s.pLng}');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('إحداثيات يدوية'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: la, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true), decoration: const InputDecoration(labelText: 'خط العرض')),
          TextField(controller: lo, keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true), decoration: const InputDecoration(labelText: 'خط الطول')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
              onPressed: () {
                final a = double.tryParse(la.text), b = double.tryParse(lo.text);
                if (a == null || b == null || a.abs() > 90 || b.abs() > 180) return _msg('إحداثيات غير صحيحة');
                widget.s.updatePrayer(() {
                  widget.s.pCity = -1;
                  widget.s.pLat = a;
                  widget.s.pLng = b;
                  widget.s.pTz = 'local';
                  widget.s.pName = 'موقع مخصص';
                });
                Navigator.pop(ctx);
              },
              child: const Text('حفظ')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: widget.s,
        builder: (context, _) {
          final s = widget.s;
          final cs = Theme.of(context).colorScheme;
          final n = s.nextPrayer();
          Widget title(String t) => Padding(
              padding: const EdgeInsets.only(top: 18, bottom: 6),
              child: Text(t, style: TextStyle(fontSize: 22, fontFamily: quranFont, fontWeight: FontWeight.w700, color: cs.primary)));
          return ListView(padding: const EdgeInsets.all(16), children: [
            Text('أوقات الصلاة', style: TextStyle(fontSize: 28, fontFamily: quranFont, fontWeight: FontWeight.w700, color: cs.primary)),
            NextPrayerCard(s),
            Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(hijriToday(s.hAdj), textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant))),
            Card(
              color: cs.surface,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: cs.outlineVariant)),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(children: [
                  Text('صلواتي', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
                  const SizedBox(height: 6),
                  Wrap(spacing: 8, children: [
                    ChoiceChip(label: const Text('اليوم'), selected: _prOff == 0, onSelected: (_) => setState(() => _prOff = 0)),
                    ChoiceChip(label: const Text('أمس'), selected: _prOff == 1, onSelected: (_) => setState(() => _prOff = 1)),
                  ]),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, runSpacing: 4, alignment: WrapAlignment.center, children: [
                    for (var i = 0; i < 5; i++)
                      FilterChip(
                        label: Text(['الفجر', 'الظهر', 'العصر', 'المغرب', 'العشاء'][i]),
                        selected: ((s.prMask(_prOff) >> i) & 1) == 1,
                        onSelected: (_) => s.togglePrayer(_prOff, i),
                      ),
                  ]),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 56,
                    child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      for (var o = 6; o >= 0; o--)
                        Expanded(
                          child: Container(
                            height: 4 + 40 * s.prCount(s.prMask(o)) / 5,
                            margin: const EdgeInsets.symmetric(horizontal: 5),
                            decoration: BoxDecoration(
                                color: s.prCount(s.prMask(o)) == 5 ? cs.primary : cs.primary.withOpacity(.4), borderRadius: BorderRadius.circular(6)),
                          ),
                        ),
                    ]),
                  ),
                  const SizedBox(height: 6),
                  Text('${ar(s.prCount(s.prMask(_prOff)))} من ${ar(5)}، والالتزام المتواصل ${ar(s.prStreak)} يومًا بالخمس',
                      textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
                ]),
              ),
            ),
            Card(
              color: cs.surface,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: cs.outlineVariant)),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(children: [
                  Text('المناسبات الهجرية القادمة', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
                  for (final o in s.occasions)
                    ListTile(
                      dense: true,
                      title: Text(o.name),
                      subtitle: Text('${ar(o.hDay)} ${hijriMonths[o.hMonth - 1]}${o.hint.isEmpty ? '' : '، ${o.hint}'}'),
                      trailing: Text(() {
                        final d = o.daysFrom(DateTime.now());
                        return d == 0 ? 'اليوم' : (d == 1 ? 'غدًا' : '${ar(d)} يومًا');
                      }()),
                    ),
                  Text('بحسب تقويم أم القرى، وقد يختلف يومًا عن رؤية بلدك.', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 11)),
                ]),
              ),
            ),
            QiblaCard(s),
            const SizedBox(height: 8),
            for (var i = 0; i < 6; i++)
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                decoration: BoxDecoration(
                    color: cs.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: i == n.i ? cs.primary : cs.outlineVariant, width: i == n.i ? 1.6 : 1)),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(prayerNames[i], style: const TextStyle(fontSize: 18)),
                    if (s.pIqama && i != 1 && s.pIq[iqamaIndex(i)] > 0)
                      Text('الإقامة بعد ${ar(s.pIq[iqamaIndex(i)])} د: ${fmtT(n.t[i] + s.pIq[iqamaIndex(i)] / 60, s.p24)}',
                          style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                  ]),
                  Text(fmtT(n.t[i], s.p24), style:  TextStyle(fontSize: 24, fontFamily: quranFont, fontWeight: FontWeight.w700)),
                ]),
              ),
            title('الموقع'),
            DropdownButtonFormField<int>(
              value: s.pCity,
              items: [
                for (var i = 0; i < cities.length; i++) DropdownMenuItem(value: i, child: Text(cities[i].name)),
                DropdownMenuItem(value: -1, child: Text(s.pCity < 0 ? s.pName : 'موقع مخصص')),
              ],
              onChanged: (v) {
                if (v == null) return;
                s.updatePrayer(() {
                  s.pCity = v;
                  if (v >= 0) {
                    final c = cities[v];
                    s.pLat = c.lat;
                    s.pLng = c.lng;
                    s.pTz = c.tz;
                    s.pName = c.name;
                  }
                });
              },
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: _gps, icon: const Icon(Icons.my_location), label: const Text('موقعي (GPS)'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton(onPressed: _manual, child: const Text('إحداثيات يدوية'))),
            ]),
            title('طريقة الحساب'),
            DropdownButtonFormField<int>(
              value: s.pMethod,
              items: [for (var i = 0; i < prayerMethods.length; i++) DropdownMenuItem(value: i, child: Text(prayerMethods[i].name))],
              onChanged: (v) => s.updatePrayer(() => s.pMethod = v ?? 0),
            ),
            const SizedBox(height: 10),
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 1, label: Text('العصر: الجمهور')),
                ButtonSegment(value: 2, label: Text('العصر: الحنفي')),
              ],
              selected: {s.pAsr},
              onSelectionChanged: (v) => s.updatePrayer(() => s.pAsr = v.first),
            ),
            SwitchListTile(title: const Text('نظام ٢٤ ساعة'), value: s.p24, onChanged: (v) => s.updatePrayer(() => s.p24 = v)),
            SwitchListTile(
                title: const Text('رمضان: ٣٠ دقيقة إضافية للعشاء'),
                subtitle: const Text('لطريقة أم القرى فقط'),
                value: s.pRam,
                onChanged: (v) => s.updatePrayer(() => s.pRam = v)),
            SwitchListTile(
                title: const Text('صوت الأذان في الإشعار'),
                subtitle: const Text('يتطلب ملف adhan.mp3 مرخّصًا في android/app/src/main/res/raw (انظر README)'),
                value: s.pAdhan,
                onChanged: (v) => s.updatePrayer(() => s.pAdhan = v)),
            SwitchListTile(
                title: const Text('تذكير بالمناسبات الهجرية'),
                subtitle: const Text('إشعار قبل المناسبة بيوم الساعة ٨ مساءً'),
                value: s.occNotify,
                onChanged: (v) {
                  if (v) Notifier.requestPermission();
                  s.setOccNotify(v);
                }),
            ListTile(
              title: const Text('تعديل التاريخ الهجري'),
              subtitle: Text('ليوافق رؤية بلدك: ${s.hAdj > 0 ? '+' : ''}${ar(s.hAdj)} يوم'),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(onPressed: () => s.setHAdj(s.hAdj - 1), icon: const Icon(Icons.remove_circle_outline)),
                IconButton(onPressed: () => s.setHAdj(s.hAdj + 1), icon: const Icon(Icons.add_circle_outline)),
              ]),
            ),
            ListTile(
              title: const Text('تذكير قبل دخول الوقت'),
              trailing: DropdownButton<int>(
                value: s.pPre,
                items: [for (final v in const [0, 5, 10, 15, 30]) DropdownMenuItem(value: v, child: Text(v == 0 ? 'إيقاف' : '${ar(v)} دقيقة'))],
                onChanged: (v) {
                  if ((v ?? 0) > 0) Notifier.requestPermission();
                  s.updatePrayer(() => s.pPre = v ?? 0);
                },
              ),
            ),
            SwitchListTile(
              title: const Text('الإقامة'),
              subtitle: const Text('يعرض وقت الإقامة ويذكّرك بها بعد الأذان بالمدة التي تحددها'),
              value: s.pIqama,
              onChanged: (v) {
                if (v) Notifier.requestPermission();
                s.updatePrayer(() => s.pIqama = v);
              },
            ),
            if (s.pIqama)
              for (var k = 0; k < 5; k++)
                ListTile(
                  dense: true,
                  title: Text('الإقامة بعد الأذان: ${['الفجر', 'الظهر', 'العصر', 'المغرب', 'العشاء'][k]}'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(onPressed: () => s.updatePrayer(() => s.pIq[k] = (s.pIq[k] - 1).clamp(0, 60).toInt()), icon: const Icon(Icons.remove_circle_outline)),
                    SizedBox(width: 44, child: Text('${ar(s.pIq[k])} د', textAlign: TextAlign.center)),
                    IconButton(onPressed: () => s.updatePrayer(() => s.pIq[k] = (s.pIq[k] + 1).clamp(0, 60).toInt()), icon: const Icon(Icons.add_circle_outline)),
                  ]),
                ),
            SwitchListTile(
              title: const Text('إشعار عند دخول الوقت'),
              subtitle: const Text('يُجدول للأيام السبعة القادمة ويتجدد عند فتح التطبيق'),
              value: s.pNotify,
              onChanged: (v) {
                if (v) Notifier.requestPermission();
                s.updatePrayer(() => s.pNotify = v);
              },
            ),
            title('ضبط الدقائق يدويًا'),
            for (var i = 0; i < 6; i++)
              ListTile(
                dense: true,
                title: Text(prayerNames[i]),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(onPressed: () => s.updatePrayer(() => s.pAdj[i] = (s.pAdj[i] - 1).clamp(-30, 30).toInt()), icon: const Icon(Icons.remove_circle_outline)),
                  SizedBox(width: 36, child: Text(ar(s.pAdj[i]), textAlign: TextAlign.center)),
                  IconButton(onPressed: () => s.updatePrayer(() => s.pAdj[i] = (s.pAdj[i] + 1).clamp(-30, 30).toInt()), icon: const Icon(Icons.add_circle_outline)),
                ]),
              ),
            Text('تُحسب الأوقات على جهازك بدون إنترنت. طابقها مع تقويم مدينتك وعدّل الدقائق عند الحاجة.',
                textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
          ]);
        },
      );
}

// ───────────────────────── المظهر ─────────────────────────
List<Widget> themeSettings(BuildContext context, AppState s) {
  final cs = Theme.of(context).colorScheme;
  Widget heading(String t) => Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
      child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, color: cs.primary)));
  Widget swatch(Color color, bool on, VoidCallback tap, {Gradient? g}) => GestureDetector(
        onTap: tap,
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: g == null ? color : null,
            gradient: g,
            border: Border.all(color: on ? cs.primary : cs.outlineVariant, width: on ? 3 : 1),
          ),
        ),
      );
  return [
    heading('المظهر'),
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: SegmentedButton<String>(
        segments: const [
          ButtonSegment(value: 'auto', label: Text('تلقائي')),
          ButtonSegment(value: 'light', label: Text('فاتح')),
          ButtonSegment(value: 'dark', label: Text('داكن')),
        ],
        selected: {s.themeMode},
        onSelectionChanged: (v) => s.setTheme(mode: v.first),
      ),
    ),
    SwitchListTile(title: const Text('أسود كامل (AMOLED) في الوضع الداكن'), value: s.amoled, onChanged: s.setAmoled),
    heading('السمة: ${palettes[s.palette].name}'),
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Wrap(spacing: 12, runSpacing: 12, children: [
        for (var i = 0; i < palettes.length; i++)
          swatch(
            Color(palettes[i].dark.bg),
            s.palette == i,
            () => s.setTheme(pal: i),
            g: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(palettes[i].dark.bg), Color(palettes[i].dark.bg), Color(palettes[i].dark.primary), Color(palettes[i].dark.primary)],
              stops: const [0, .5, .5, 1],
            ),
          ),
      ]),
    ),
    heading('لون التمييز'),
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Wrap(spacing: 12, runSpacing: 12, crossAxisAlignment: WrapCrossAlignment.center, children: [
        for (final a in accentPresets) swatch(Color(a), s.accent == a, () => s.setTheme(acc: a)),
        OutlinedButton(onPressed: () => _customColor(context, s), child: const Text('لون مخصص')),
        TextButton(onPressed: () => s.setTheme(clearAccent: true), child: const Text('إعادة')),
      ]),
    ),
    heading('خط القرآن والأذكار'),
    for (final f in quranFonts)
      ListTile(
        dense: true,
        title: Text(f.label),
        subtitle: Text('ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ', style: TextStyle(fontFamily: f.family, fontSize: 22)),
        trailing: Icon(s.quranFontId == f.family ? Icons.radio_button_checked : Icons.radio_button_unchecked,
            color: s.quranFontId == f.family ? cs.primary : cs.outline),
        onTap: () => s.setFonts(quran: f.family),
      ),
    heading('خط الواجهة'),
    for (final f in uiFonts)
      ListTile(
        dense: true,
        title: Text(f.label),
        subtitle: Text('مسبحة وأذكار وقرآن', style: TextStyle(fontFamily: f.family.isEmpty ? null : f.family, fontSize: 16)),
        trailing: Icon(s.uiFontId == f.family ? Icons.radio_button_checked : Icons.radio_button_unchecked,
            color: s.uiFontId == f.family ? cs.primary : cs.outline),
        onTap: () => s.setFonts(ui: f.family),
      ),
    const SizedBox(height: 8),
    const Divider(),
  ];
}

void _customColor(BuildContext context, AppState s) {
  var r = 217, g = 183, b = 101;
  if (s.accent != null) {
    final v = s.accent!;
    r = (v >> 16) & 255;
    g = (v >> 8) & 255;
    b = v & 255;
  }
  showDialog(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: const Text('لون مخصص'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(height: 48, decoration: BoxDecoration(color: Color.fromARGB(255, r, g, b), borderRadius: BorderRadius.circular(12))),
          Slider(value: r.toDouble(), min: 0, max: 255, activeColor: Colors.red, onChanged: (v) => set(() => r = v.round())),
          Slider(value: g.toDouble(), min: 0, max: 255, activeColor: Colors.green, onChanged: (v) => set(() => g = v.round())),
          Slider(value: b.toDouble(), min: 0, max: 255, activeColor: Colors.blue, onChanged: (v) => set(() => b = v.round())),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
              onPressed: () {
                s.setTheme(acc: (255 << 24) | (r << 16) | (g << 8) | b);
                Navigator.pop(ctx);
              },
              child: const Text('تطبيق')),
        ],
      ),
    ),
  );
}

// ───────────────────────── القبلة والتاريخ الهجري والاستعادة ─────────────────────────
const _hijriMonths = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];

String hijriToday([int adj = 0]) {
  final h = HijriCalendar.fromDate(DateTime.now().add(Duration(days: adj)));
  return '${ar(h.hDay)} ${_hijriMonths[h.hMonth - 1]} ${ar(h.hYear)} هـ';
}

class QiblaCard extends StatefulWidget {
  final AppState s;
  const QiblaCard(this.s, {super.key});
  @override
  State<QiblaCard> createState() => _QiblaState();
}

class _QiblaState extends State<QiblaCard> {
  StreamSubscription<CompassEvent>? _sub;
  double? _heading;

  @override
  void initState() {
    super.initState();
    try {
      _sub = FlutterCompass.events?.listen((e) {
        if (mounted) setState(() => _heading = e.heading);
      });
    } catch (_) {}
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.s;
    final cs = Theme.of(context).colorScheme;
    final b = PrayerCalc.qibla(s.pLat, s.pLng);
    final atKaaba = (s.pLat - 21.4225).abs() < .02 && (s.pLng - 39.8262).abs() < .02;
    final h = _heading;
    return Card(
      color: cs.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: cs.outlineVariant)),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(children: [
          Text('اتجاه القبلة من ${s.pName}', style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
          const SizedBox(height: 8),
          SizedBox(
            width: 150,
            height: 150,
            child: Stack(alignment: Alignment.center, children: [
              Transform.rotate(
                angle: h == null ? 0 : -h * math.pi / 180,
                child: Container(
                  decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: cs.outlineVariant, width: 2)),
                  child: Align(alignment: Alignment.topCenter, child: Padding(padding: const EdgeInsets.only(top: 6), child: Text('ش', style: TextStyle(color: cs.onSurfaceVariant)))),
                ),
              ),
              Transform.rotate(angle: ((h == null ? b : b - h)) * math.pi / 180, child: Icon(Icons.navigation, size: 68, color: cs.primary)),
            ]),
          ),
          Text(atKaaba ? 'أنت عند الكعبة المشرفة' : '${ar(b.round())}° من الشمال',
              style: TextStyle(fontSize: 24, fontFamily: quranFont, fontWeight: FontWeight.w700, color: cs.primary)),
          Text(h == null ? 'الزاوية من الشمال الحقيقي. البوصلة الحية غير متاحة على هذا الجهاز.' : 'أدر الجهاز أفقيًا حتى يشير السهم للأعلى، وابتعد عن المعادن.',
              textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12)),
        ]),
      ),
    );
  }
}

void restoreDialog(BuildContext context, AppState s) {
  final ctrl = TextEditingController();
  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('استعادة من نسخة احتياطية'),
      content: TextField(controller: ctrl, maxLines: 5, decoration: const InputDecoration(hintText: 'الصق النسخة الاحتياطية هنا')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(
          onPressed: () async {
            final ok = await s.importJson(ctrl.text);
            if (ctx.mounted) Navigator.pop(ctx);
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'تمت الاستعادة' : 'النص غير صالح')));
            }
          },
          child: const Text('استعادة'),
        ),
      ],
    ),
  );
}

// ───────────────────────── الترحيب وقائمة أذكاري ─────────────────────────
class OnboardingScreen extends StatefulWidget {
  final AppState s;
  const OnboardingScreen(this.s, {super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardState();
}

class _OnboardState extends State<OnboardingScreen> {
  final pc = PageController();
  int page = 0, city = 0;
  static const slides = [
    ('أهلًا بك في تسابيح', 'مسبحة إلكترونية، وأذكار الصباح والمساء، والقرآن الكريم، وأوقات الصلاة في مكان واحد.'),
    ('كل ما تحتاجه', 'اضغط في أي مكان للتسبيح، وتصفّح الأذكار بحسب الوقت، واقرأ القرآن بتمرير تلقائي، وتابع أوقات الصلاة والقبلة.'),
    ('خصوصيتك محفوظة', 'لا حسابات ولا إعلانات ولا جمع للبيانات. كل شيء يبقى على جهازك.'),
    ('لتصلك الإشعارات في وقتها', 'بعض الأجهزة توقف التطبيقات في الخلفية. من الإعدادات ← التطبيقات ← تسابيح ← البطارية اختر «غير مقيّد»، وفعّل التشغيل التلقائي إن وُجد (شاومي وهواوي وأوبو). ستجد الشرح لاحقًا في الإعدادات.'),
    ('اختر مدينتك', 'لتظهر أوقات الصلاة الصحيحة. يمكنك تغييرها لاحقًا من تبويب الصلاة.'),
  ];

  @override
  void dispose() {
    pc.dispose();
    super.dispose();
  }

  void _finish({bool withCity = false}) {
    final s = widget.s;
    if (withCity) {
      final c = cities[city];
      s.updatePrayer(() {
        s.pCity = city;
        s.pLat = c.lat;
        s.pLng = c.lng;
        s.pTz = c.tz;
        s.pName = c.name;
      });
    }
    s.finishOnboarding();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final last = page == slides.length - 1;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(children: [
            Expanded(
              child: PageView(controller: pc, onPageChanged: (i) => setState(() => page = i), children: [
                for (var i = 0; i < slides.length; i++)
                  Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text('✦', style: TextStyle(fontSize: 64, color: cs.primary)),
                    Text(slides[i].$1, textAlign: TextAlign.center, style: TextStyle(fontSize: 32, fontFamily: quranFont, fontWeight: FontWeight.w700, color: cs.primary)),
                    const SizedBox(height: 8),
                    Text(slides[i].$2, textAlign: TextAlign.center, style: TextStyle(color: cs.onSurfaceVariant, height: 1.7)),
                    if (i == slides.length - 1) ...[
                      const SizedBox(height: 16),
                      DropdownButtonFormField<int>(
                        value: city,
                        items: [for (var j = 0; j < cities.length; j++) DropdownMenuItem(value: j, child: Text(cities[j].name))],
                        onChanged: (v) => setState(() => city = v ?? 0),
                      ),
                    ],
                  ]),
              ]),
            ),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (var i = 0; i < slides.length; i++)
                Container(
                  width: 8,
                  height: 8,
                  margin: const EdgeInsets.all(4),
                  decoration: BoxDecoration(shape: BoxShape.circle, color: i == page ? cs.primary : cs.outlineVariant),
                ),
            ]),
            const SizedBox(height: 12),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              OutlinedButton(onPressed: _finish, child: const Text('تخطي')),
              const SizedBox(width: 12),
              FilledButton(
                onPressed: () => last ? _finish(withCity: true) : pc.nextPage(duration: const Duration(milliseconds: 250), curve: Curves.easeOut),
                child: Text(last ? 'ابدأ' : 'التالي'),
              ),
            ]),
          ]),
        ),
      ),
    );
  }
}

void addUzDialog(BuildContext context, AppState s) {
  final t = TextEditingController(), n = TextEditingController(text: '1');
  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('ذكر في قائمتي'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: t, maxLines: 3, decoration: const InputDecoration(labelText: 'نص الذكر أو الدعاء')),
        TextField(controller: n, keyboardType: TextInputType.number, inputFormatters: [FilteringTextInputFormatter.digitsOnly], decoration: const InputDecoration(labelText: 'عدد التكرار')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(
          onPressed: () {
            if (t.text.trim().isNotEmpty) s.addUz(t.text.trim(), int.tryParse(n.text) ?? 1);
            Navigator.pop(ctx);
          },
          child: const Text('إضافة'),
        ),
      ],
    ),
  );
}

// ───────────────────────── إحصائيات ٣٠ يومًا وتعليمات البطارية ─────────────────────────
List<Widget> monthStats(BuildContext context, AppState s) {
  final cs = Theme.of(context).colorScheme;
  final now = DateTime.now();
  final a = [for (var i = 29; i >= 0; i--) s.hist[dayKey(now.subtract(Duration(days: i)))] ?? 0];
  final sum = a.fold<int>(0, (x, y) => x + y);
  final mx = a.fold<int>(1, (x, y) => y > x ? y : x);
  final active = a.where((x) => x > 0).length;
  Widget card(String label, String v) => Expanded(
        child: Card(
          color: cs.secondaryContainer,
          elevation: 0,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Column(children: [
              FittedBox(child: Text(v, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: cs.primary))),
              Text(label, style: const TextStyle(fontSize: 12)),
            ]),
          ),
        ),
      );
  return [
    const SizedBox(height: 16),
    Text('آخر ٣٠ يومًا', style: Theme.of(context).textTheme.titleMedium),
    const SizedBox(height: 8),
    Row(children: [card('المجموع', ar(sum)), card('المتوسط اليومي', ar((sum / 30).round())), card('أيام نشطة', ar(active))]),
    const SizedBox(height: 10),
    SizedBox(
      height: 90,
      child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        for (final v in a)
          Expanded(
            child: Container(
              height: 3 + 80 * v / mx,
              margin: const EdgeInsets.symmetric(horizontal: 1),
              decoration: BoxDecoration(color: v > 0 ? cs.primary : cs.outlineVariant, borderRadius: BorderRadius.circular(3)),
            ),
          ),
      ]),
    ),
    const SizedBox(height: 16),
  ];
}

void batteryHelp(BuildContext context) {
  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('لتصلك الإشعارات في وقتها'),
      content: const SingleChildScrollView(
        child: Text(
          'بعض الأجهزة توقف التطبيقات في الخلفية لتوفير البطارية، فتتأخر الإشعارات أو لا تصل. جرّب:\n\n'
          '١. الإعدادات ← التطبيقات ← تسابيح ← البطارية، واختر «غير مقيّد» أو «بدون قيود».\n\n'
          '٢. شاومي: الأمان ← الأذونات ← التشغيل التلقائي، فعّل تسابيح. وفي البطارية اختر «بدون قيود».\n\n'
          '٣. هواوي: إدارة التطبيقات ← تسابيح ← التشغيل اليدوي، وفعّل التشغيل التلقائي والتشغيل الثانوي والتشغيل في الخلفية.\n\n'
          '٤. سامسونج: البطارية ← حدود استخدام الخلفية، وأخرج تسابيح من «التطبيقات النائمة».\n\n'
          '٥. أوبو وريلمي وفيفو: السماح بالتشغيل التلقائي وبالنشاط في الخلفية.\n\n'
          '٦. تأكد من تفعيل إذن الإشعارات للتطبيق، ومن عدم تفعيل «عدم الإزعاج».\n\n'
          'تختلف المسارات بحسب الجهاز وإصدار أندرويد.',
          style: TextStyle(height: 1.7),
        ),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('حسنًا'))],
    ),
  );
}
