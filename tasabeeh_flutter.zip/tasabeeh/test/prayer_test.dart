import 'package:flutter_test/flutter_test.dart';
import 'package:tasabeeh/prayer.dart';

List<double> riyadh(int method, {int asr = 1, List<int>? adj}) => PrayerCalc.times(
      y: 2026, m: 11, d: 6, lat: 24.7136, lng: 46.6753, tzh: 3,
      method: prayerMethods[method], asr: asr, adj: adj ?? [0, 0, 0, 0, 0, 0]);

void main() {
  test('ترتيب الأوقات منطقي', () {
    final t = riyadh(0);
    for (var i = 0; i < 5; i++) {
      expect(t[i] < t[i + 1], isTrue, reason: prayerNames[i]);
    }
  });

  test('أوقات الرياض (٦ نوفمبر) ضمن نطاق معقول', () {
    final t = riyadh(0);
    expect(t[0], inInclusiveRange(4.5, 5.0)); // الفجر
    expect(t[1], inInclusiveRange(5.9, 6.3)); // الشروق
    expect(t[2], inInclusiveRange(11.5, 11.8)); // الظهر
    expect(t[3], inInclusiveRange(14.6, 15.0)); // العصر
    expect(t[4], inInclusiveRange(17.0, 17.4)); // المغرب
    expect(t[5], inInclusiveRange(18.4, 18.9)); // العشاء
  });

  test('أم القرى: العشاء بعد المغرب بـ٩٠ دقيقة', () {
    final t = riyadh(0);
    expect((t[5] - t[4]) * 60, closeTo(90, 0.01));
  });

  test('الحنفي يؤخر العصر، والضبط اليدوي يزيح الدقائق', () {
    expect(riyadh(0, asr: 2)[3] > riyadh(0)[3], isTrue);
    expect((riyadh(0, adj: [0, 0, 5, 0, 0, 0])[2] - riyadh(0)[2]) * 60, closeTo(5, 0.001));
  });

  test('كل طرق الحساب ترجع أوقاتًا صالحة', () {
    for (var i = 0; i < prayerMethods.length; i++) {
      for (final v in riyadh(i)) {
        expect(v.isNaN, isFalse, reason: prayerMethods[i].name);
      }
    }
  });
}
