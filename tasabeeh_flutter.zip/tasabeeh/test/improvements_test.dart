import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tasabeeh/occasions.dart';
import 'package:tasabeeh/prayer.dart';
import 'package:tasabeeh/state.dart';
import 'package:tasabeeh/theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('كل طرق الحساب (١٤) تعطي أوقاتًا صالحة ومرتبة', () {
    expect(prayerMethods.length, 14);
    for (var i = 0; i < prayerMethods.length; i++) {
      final t = PrayerCalc.times(
          y: 2026, m: 11, d: 6, lat: 24.7136, lng: 46.6753, tzh: 3, method: prayerMethods[i], asr: 1, adj: [0, 0, 0, 0, 0, 0]);
      for (var k = 0; k < 5; k++) {
        expect(t[k].isNaN || t[k + 1].isNaN, isFalse, reason: prayerMethods[i].name);
        expect(t[k] < t[k + 1], isTrue, reason: prayerMethods[i].name);
      }
    }
  });

  test('دقة الحساب: الظهر والشروق للرياض ضمن دقيقتين من القيم المرجعية لشهر نوفمبر', () {
    final t = PrayerCalc.times(
        y: 2026, m: 11, d: 6, lat: 24.7136, lng: 46.6753, tzh: 3, method: prayerMethods[1], asr: 1, adj: [0, 0, 0, 0, 0, 0]);
    expect(t[2], closeTo(11.62, 0.05));
    expect(t[1], closeTo(6.05, 0.05));
  });

  test('تعديل التاريخ الهجري يُقيَّد ويُحفظ ويحرّك المناسبات', () async {
    SharedPreferences.setMockInitialValues({});
    final s = AppState();
    await s.load();
    s.setHAdj(5);
    expect(s.hAdj, 2);
    s.setHAdj(-7);
    expect(s.hAdj, -2);
    s.setHAdj(1);
    final s2 = AppState();
    await s2.load();
    expect(s2.hAdj, 1);
    final from = DateTime(2026, 11, 8);
    final a = upcomingOccasions(from, max: 1, adj: 0).first, b = upcomingOccasions(from, max: 1, adj: 1).first;
    expect(b.name != a.name || b.date.isBefore(a.date), isTrue);
  });

  test('الأسود الكامل يؤثر في الوضع الداكن فقط', () {
    expect(buildTheme(Brightness.dark, 0, null, amoled: true).scaffoldBackgroundColor, const Color(0xFF000000));
    expect(buildTheme(Brightness.light, 0, null, amoled: true).scaffoldBackgroundColor == const Color(0xFF000000), isFalse);
    expect(buildTheme(Brightness.dark, 0, null).scaffoldBackgroundColor == const Color(0xFF000000), isFalse);
  });
}
