import 'package:home_widget/home_widget.dart';
import 'package:timezone/timezone.dart' as tz;
import 'prayer.dart';
import 'state.dart';

/// يرسل أوقات الصلاة القادمة لويدجت الشاشة الرئيسية (أندرويد)
class WidgetSync {
  static String _fmt(double h, bool h24) {
    if (h.isNaN) return '--:--';
    var t = h + .5 / 60;
    t = t - 24 * (t / 24).floorToDouble();
    var hh = t.floor();
    final mm = ((t - hh) * 60).floor();
    var suf = '';
    if (!h24) {
      suf = hh >= 12 ? ' م' : ' ص';
      hh = hh % 12 == 0 ? 12 : hh % 12;
    }
    return '${ar(hh.toString().padLeft(h24 ? 2 : 1, '0'))}:${ar(mm.toString().padLeft(2, '0'))}$suf';
  }

  static Future<void> update(AppState s) async {
    try {
      final now = tz.TZDateTime.now(s.pLoc);
      final parts = <String>[];
      for (var d = 0; d < 3; d++) {
        final dt = tz.TZDateTime(s.pLoc, now.year, now.month, now.day + d);
        final t = s.prayerFor(dt.year, dt.month, dt.day);
        for (final i in [0, 2, 3, 4, 5]) {
          if (t[i].isNaN) continue;
          final when = tz.TZDateTime(s.pLoc, dt.year, dt.month, dt.day, 0, (t[i] * 60).round());
          if (when.isAfter(now)) parts.add('${prayerNames[i]}|${when.millisecondsSinceEpoch}|${_fmt(t[i], s.p24)}');
        }
      }
      await HomeWidget.saveWidgetData<String>('prayers', parts.join(';'));
      await HomeWidget.saveWidgetData<String>('city', s.pName);
      await HomeWidget.updateWidget(name: 'PrayerWidgetProvider', androidName: 'PrayerWidgetProvider');
    } catch (_) {}
  }
}
