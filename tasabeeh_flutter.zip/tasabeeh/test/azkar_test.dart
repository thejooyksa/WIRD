import 'package:flutter_test/flutter_test.dart';
import 'package:tasabeeh/azkar.dart';
import 'package:tasabeeh/quran.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('معرّفات الأذكار فريدة والأعداد صحيحة والنصوص غير فارغة', () {
    final all = [...azkar, ...azkarMore];
    expect(all.map((z) => z.id).toSet().length, all.length);
    for (final z in all) {
      expect(z.n >= 1, isTrue, reason: z.id);
      expect(z.q != null || (z.m ?? z.e ?? '').isNotEmpty, isTrue, reason: z.id);
    }
  });

  test('كل الفئات موجودة', () {
    for (final c in ['s', 'p', 'w', 'd']) {
      expect(azkarMore.where((z) => z.cat == c).isNotEmpty, isTrue, reason: c);
    }
  });

  test('الآيات المشار إليها موجودة في المصحف', () async {
    await Quran.load();
    for (final z in azkarMore.where((z) => z.q != null)) {
      final q = z.q!;
      final l = Quran.data[q[0]];
      expect(l, isNotNull, reason: z.id);
      if (q.length == 2) expect(q[1] <= l!.length, isTrue, reason: z.id);
      if (q.length == 3) expect(q[2] <= l!.length, isTrue, reason: z.id);
    }
  });
}
