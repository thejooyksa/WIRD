import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'notifications.dart';
import 'quick_counter.dart';
import 'quran.dart';
import 'screens.dart';
import 'theme.dart';
import 'widget_sync.dart';
import 'state.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Notifier.init(onBackground: quickCounterBackground);
  await Quran.load();
  final s = AppState();
  await s.load();
  await s.rescheduleAll();
  s.refreshQuick();
  Notifier.actionHandler = (r) {
    if (r.actionId == 'count_plus') {
      s.tap(feedback: false);
    } else {
      s.undo();
    }
  };
  WidgetsBinding.instance.addObserver(_ResumeReload(s));
  WidgetSync.update(s);
  var sig = '';
  s.addListener(() {
    final n = '${s.pLat}|${s.pLng}|${s.pTz}|${s.pMethod}|${s.pAsr}|${s.pAdj}|${s.pRam}|${s.p24}';
    if (n != sig) {
      sig = n;
      WidgetSync.update(s);
    }
  });
  runApp(TasabeehApp(s));
}

/// عند عودة التطبيق للواجهة نعيد قراءة البيانات لأن الإشعار قد يكون عدّ في الخلفية
class _ResumeReload with WidgetsBindingObserver {
  final AppState s;
  _ResumeReload(this.s);
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) s.reload();
  }
}

class TasabeehApp extends StatelessWidget {
  final AppState s;
  const TasabeehApp(this.s, {super.key});

  ThemeData _theme(Brightness b) => buildTheme(b, s.palette, s.accent, font: s.uiFontId, amoled: s.amoled);

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: s,
        builder: (_, __) => MaterialApp(
          title: 'تسابيح',
          debugShowCheckedModeBanner: false,
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          themeMode: s.themeMode == 'auto' ? ThemeMode.system : (s.themeMode == 'light' ? ThemeMode.light : ThemeMode.dark),
          theme: _theme(Brightness.light),
          darkTheme: _theme(Brightness.dark),
          home: s.onboarded ? HomeShell(s) : OnboardingScreen(s),
        ),
      );
}
