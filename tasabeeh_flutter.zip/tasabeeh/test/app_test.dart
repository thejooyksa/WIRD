import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tasabeeh/main.dart';
import 'package:tasabeeh/screens.dart';
import 'package:tasabeeh/state.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

Future<AppState> fresh() async {
  SharedPreferences.setMockInitialValues({});
  final s = AppState();
  await s.load();
  s.haptics = false;
  s.onboarded = true;
  return s;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() {
    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation('Asia/Riyadh'));
  });

  test('العدّ والتراجع والإحصاء', () async {
    final s = await fresh();
    for (var i = 0; i < 5; i++) {
      s.tap();
    }
    expect(s.sessionCount, 5);
    expect(s.today, 5);
    expect(s.total, 5);
    s.undo();
    expect(s.sessionCount, 4);
    expect(s.today, 4);
    expect(s.streak, 1);
  });

  test('تسبيح ما بعد الصلاة ينتقل: سبحان الله ثم الحمد لله ثم الله أكبر', () async {
    final s = await fresh();
    s.toggleSeq();
    for (var i = 0; i < 33; i++) {
      s.tap();
    }
    expect(s.currentId, 'hamd');
    for (var i = 0; i < 33; i++) {
      s.tap();
    }
    expect(s.currentId, 'akbar');
    for (var i = 0; i < 34; i++) {
      s.tap();
    }
    expect(s.seq, isFalse);
  });

  test('الأذكار لا تتجاوز عددها، والبيانات تُحفظ وتُسترجع', () async {
    final s = await fresh();
    for (var i = 0; i < 5; i++) {
      s.azTap('k', 3);
    }
    expect(s.az['k'], 3);
    s.tap();
    s.tap();
    final s2 = AppState();
    await s2.load();
    expect(s2.sessionCount, 2);
  });

  testWidgets('الضغط على العداد يزيد الرقم، وكل التبويبات تُعرض بلا أخطاء', (tester) async {
    final s = (await tester.runAsync(fresh))!;
    await tester.pumpWidget(TasabeehApp(s));
    await tester.pump();
    final ring = find.byWidgetPredicate((w) => w is CustomPaint && w.painter is BeadsPainter);
    await tester.tap(ring);
    await tester.pump();
    expect(s.sessionCount, 1);
    for (final label in ['الأذكار', 'الصلاة', 'القرآن', 'الإحصائيات', 'الإعدادات', 'العداد']) {
      await tester.tap(find.text(label));
      await tester.pump();
      expect(tester.takeException(), isNull, reason: label);
    }
    await tester.pumpWidget(const SizedBox());
  });
}
