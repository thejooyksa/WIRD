import 'package:flutter_test/flutter_test.dart';
import 'package:tasabeeh/prayer.dart';

void main() {
  test('رمضان: العشاء بعد المغرب بساعتين عند أم القرى', () {
    final t = PrayerCalc.times(
        y: 2027, m: 2, d: 15, lat: 24.7136, lng: 46.6753, tzh: 3, method: prayerMethods[0], asr: 1,
        adj: [0, 0, 0, 0, 0, 0], ishaExtra: 30);
    expect((t[5] - t[4]) * 60, closeTo(120, 0.01));
  });

  test('اتجاه القبلة من مدن معروفة', () {
    expect(PrayerCalc.qibla(51.5074, -0.1278), closeTo(119, 1.5));
    expect(PrayerCalc.qibla(30.0444, 31.2357), closeTo(136.2, 1.5));
    expect(PrayerCalc.qibla(24.7136, 46.6753), closeTo(244, 1.5));
  });
}
