import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'notifications.dart';
import 'state.dart';

/// يعمل في عملية خلفية عند الضغط على «+١» أو «تراجع» في الإشعار والتطبيق غير ظاهر
@pragma('vm:entry-point')
Future<void> quickCounterBackground(NotificationResponse r) async {
  if (r.actionId != 'count_plus' && r.actionId != 'count_undo') return;
  try {
    await Notifier.initBasic();
    final s = AppState();
    await s.load();
    if (!s.quickNotif) return;
    if (r.actionId == 'count_plus') {
      s.tap(feedback: false);
    } else {
      s.undo();
    }
    await s.saveNow();
  } catch (_) {}
}
