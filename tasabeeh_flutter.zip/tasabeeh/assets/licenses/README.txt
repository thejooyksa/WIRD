تراخيص الخطوط (SIL OFL) تُضاف هنا تلقائيًا عند تشغيل tool/setup_fonts.py
