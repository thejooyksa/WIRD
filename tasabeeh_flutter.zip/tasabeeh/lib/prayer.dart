import 'dart:math' as math;

class PMethod {
  final String name;
  final double fajr, isha;
  final int ishaMin; // إن كانت > 0 فالعشاء = المغرب + هذه الدقائق
  const PMethod(this.name, this.fajr, this.isha, this.ishaMin);
}

class City {
  final String name, tz;
  final double lat, lng;
  const City(this.name, this.lat, this.lng, this.tz);
}

/// فهرس الإقامة (فجر، ظهر، عصر، مغرب، عشاء) من فهرس الصلاة (٠ فجر، ١ شروق، ٢ ظهر، ...)
int iqamaIndex(int prayer) => prayer == 0 ? 0 : prayer - 1;

const prayerNames = ['الفجر', 'الشروق', 'الظهر', 'العصر', 'المغرب', 'العشاء'];

const prayerMethods = [
  PMethod('أم القرى', 18.5, 0, 90),
  PMethod('رابطة العالم الإسلامي', 18, 17, 0),
  PMethod('الهيئة المصرية العامة للمساحة', 19.5, 17.5, 0),
  PMethod('جامعة العلوم الإسلامية بكراتشي', 18, 18, 0),
  PMethod('أمريكا الشمالية (ISNA)', 15, 15, 0),
  PMethod('الكويت', 18, 17.5, 0),
  PMethod('قطر', 18, 0, 90),
  PMethod('الإمارات والخليج', 18.2, 18.2, 0),
  PMethod('المغرب', 19, 17, 0),
  PMethod('تركيا (ديانت)', 18, 17, 0),
  PMethod('الأردن', 18, 18, 0),
  PMethod('الجزائر', 18, 17, 0),
  PMethod('تونس', 18, 18, 0),
  PMethod('سنغافورة', 20, 18, 0),
];

const cities = [
  City('مكة المكرمة', 21.4225, 39.8262, 'Asia/Riyadh'),
  City('المدينة المنورة', 24.4672, 39.6111, 'Asia/Riyadh'),
  City('الرياض', 24.7136, 46.6753, 'Asia/Riyadh'),
  City('جدة', 21.5433, 39.1728, 'Asia/Riyadh'),
  City('الدمام', 26.4207, 50.0888, 'Asia/Riyadh'),
  City('أبها', 18.2164, 42.5053, 'Asia/Riyadh'),
  City('تبوك', 28.3838, 36.555, 'Asia/Riyadh'),
  City('القاهرة', 30.0444, 31.2357, 'Africa/Cairo'),
  City('الإسكندرية', 31.2001, 29.9187, 'Africa/Cairo'),
  City('دبي', 25.2048, 55.2708, 'Asia/Dubai'),
  City('أبوظبي', 24.4539, 54.3773, 'Asia/Dubai'),
  City('الكويت', 29.3759, 47.9774, 'Asia/Kuwait'),
  City('الدوحة', 25.2854, 51.531, 'Asia/Qatar'),
  City('المنامة', 26.2285, 50.586, 'Asia/Bahrain'),
  City('مسقط', 23.588, 58.3829, 'Asia/Muscat'),
  City('صنعاء', 15.3694, 44.191, 'Asia/Aden'),
  City('عمّان', 31.9454, 35.9284, 'Asia/Amman'),
  City('بغداد', 33.3152, 44.3661, 'Asia/Baghdad'),
  City('دمشق', 33.5138, 36.2765, 'Asia/Damascus'),
  City('بيروت', 33.8938, 35.5018, 'Asia/Beirut'),
  City('الخرطوم', 15.5007, 32.5599, 'Africa/Khartoum'),
  City('طرابلس', 32.8872, 13.1913, 'Africa/Tripoli'),
  City('تونس', 36.8065, 10.1815, 'Africa/Tunis'),
  City('الجزائر', 36.7538, 3.0588, 'Africa/Algiers'),
  City('الرباط', 34.0209, -6.8416, 'Africa/Casablanca'),
  City('الدار البيضاء', 33.5731, -7.5898, 'Africa/Casablanca'),
  City('إسطنبول', 41.0082, 28.9784, 'Europe/Istanbul'),
  City('لندن', 51.5074, -0.1278, 'Europe/London'),
];

class PrayerCalc {
  /// اتجاه القبلة بالدرجات من الشمال الحقيقي (باتجاه عقارب الساعة)
  static double qibla(double lat, double lng) {
    final f1 = lat * math.pi / 180, f2 = 21.4225 * math.pi / 180, dl = (39.8262 - lng) * math.pi / 180;
    final b = math.atan2(math.sin(dl), math.cos(f1) * math.tan(f2) - math.sin(f1) * math.cos(dl)) * 180 / math.pi;
    return (b + 360) % 360;
  }

  static double _s(double d) => math.sin(d * math.pi / 180);
  static double _c(double d) => math.cos(d * math.pi / 180);
  static double _t(double d) => math.tan(d * math.pi / 180);
  static double _as(double x) => math.asin(x) * 180 / math.pi;
  static double _ac(double x) => math.acos(x) * 180 / math.pi;
  static double _at2(double y, double x) => math.atan2(y, x) * 180 / math.pi;
  static double _acot(double x) => math.atan(1 / x) * 180 / math.pi;
  static double _fa(double a) => a - 360 * (a / 360).floorToDouble();
  static double _fh(double h) => h - 24 * (h / 24).floorToDouble();

  static double _jul(int y, int m, int d) {
    if (m <= 2) {
      y -= 1;
      m += 12;
    }
    final a = (y / 100).floor();
    final b = 2 - a + (a / 4).floor();
    return (365.25 * (y + 4716)).floor() + (30.6001 * (m + 1)).floor() + d + b - 1524.5;
  }

  /// (الميل الشمسي، معادلة الزمن)
  static (double, double) _sun(double jd) {
    final dd = jd - 2451545;
    final g = _fa(357.529 + 0.98560028 * dd);
    final q = _fa(280.459 + 0.98564736 * dd);
    final l = _fa(q + 1.915 * _s(g) + 0.02 * _s(2 * g));
    final e = 23.439 - 3.6e-7 * dd;
    final ra = _fh(_at2(_c(e) * _s(l), _c(l)) / 15);
    return (_as(_s(e) * _s(l)), q / 15 - ra);
  }

  /// يرجع ٦ أوقات بالساعات العشرية (الفجر، الشروق، الظهر، العصر، المغرب، العشاء) بتوقيت المدينة
  static List<double> times({
    required int y,
    required int m,
    required int d,
    required double lat,
    required double lng,
    required double tzh,
    required PMethod method,
    required int asr,
    required List<int> adj,
    int ishaExtra = 0, // دقائق إضافية للعشاء عند أم القرى في رمضان
  }) {
    final ishaMin = method.ishaMin > 0 ? method.ishaMin + ishaExtra : 0;
    final jd = _jul(y, m, d) - lng / 360;
    double mid(double t) => _fh(12 - _sun(jd + t).$2);
    double sat(double a, double t, bool ccw) {
      final dc = _sun(jd + t).$1;
      final v = (-_s(a) - _s(dc) * _s(lat)) / (_c(dc) * _c(lat));
      if (v.abs() > 1) return double.nan;
      return mid(t) + (ccw ? -1 : 1) * _ac(v) / 15;
    }

    double dp(double h) => h / 24;
    final o = tzh - lng / 15;
    var f = sat(method.fajr, dp(5), true) + o;
    final sr = sat(0.833, dp(6), true) + o;
    final dh = mid(dp(12)) + o;
    final dc13 = _sun(jd + dp(13)).$1;
    final as_ = sat(-_acot(asr + _t((lat - dc13).abs())), dp(13), false) + o;
    final ss = sat(0.833, dp(18), false) + o;
    var is_ = ishaMin > 0 ? double.nan : sat(method.isha, dp(18), false) + o;
    final night = _fh(sr + 24 - ss);
    if (f.isNaN) f = sr - night / 7;
    if (ishaMin > 0) {
      is_ = ss + ishaMin / 60;
    } else if (is_.isNaN) {
      is_ = ss + night / 7;
    }
    final r = [f, sr, dh, as_, ss, is_];
    return [for (var i = 0; i < 6; i++) r[i] + adj[i] / 60];
  }
}
