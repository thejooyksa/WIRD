quran-uthmani.txt from Tanzil.net (CC BY 3.0). Do not modify the text.
